import { useState } from "react";
import {
  Music2,
  Globe,
  MessageSquare,
  Gamepad2,
  Mic,
  Film,
  Radio,
  Headphones,
  ChevronDown,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

export interface AudioSource {
  id: string;
  name: string;
  icon: string;
}

const availableSources: AudioSource[] = [
  { id: "spotify", name: "Spotify", icon: "music" },
  { id: "browser", name: "Browser", icon: "globe" },
  { id: "discord", name: "Discord", icon: "message" },
  { id: "game", name: "Game Audio", icon: "gamepad" },
  { id: "microphone", name: "Microphone", icon: "mic" },
  { id: "media", name: "Media Player", icon: "film" },
  { id: "system", name: "System Audio", icon: "radio" },
  { id: "voip", name: "VoIP Call", icon: "headphones" },
];

const iconMap: Record<string, any> = {
  music: Music2,
  globe: Globe,
  message: MessageSquare,
  gamepad: Gamepad2,
  mic: Mic,
  film: Film,
  radio: Radio,
  headphones: Headphones,
};

interface SourceSelectorProps {
  currentSource?: AudioSource;
  onSourceChange: (source: AudioSource) => void;
  color: string;
}

export function SourceSelector({
  currentSource,
  onSourceChange,
  color,
}: SourceSelectorProps) {
  const [open, setOpen] = useState(false);

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          className="relative p-3 rounded-lg group"
          style={{ backgroundColor: `${color}20` }}
        >
          {currentSource ? (
            (() => {
              const Icon = iconMap[currentSource.icon] || Mic;
              return <Icon className="size-6" style={{ color }} />;
            })()
          ) : (
            <Mic className="size-6" style={{ color }} />
          )}
          <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-zinc-800 flex items-center justify-center group-hover:bg-zinc-700 transition-colors">
            <ChevronDown className="size-3 text-white" />
          </div>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56 bg-zinc-900 border-zinc-800">
        <div className="px-2 py-1.5 text-xs font-semibold text-zinc-400">
          Select Input Source
        </div>
        {availableSources.map((source) => {
          const Icon = iconMap[source.icon];
          const isSelected = currentSource?.id === source.id;
          return (
            <DropdownMenuItem
              key={source.id}
              onClick={() => {
                onSourceChange(source);
                setOpen(false);
              }}
              className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-zinc-800"
              style={{
                backgroundColor: isSelected ? `${color}20` : undefined,
              }}
            >
              <div
                className="p-1.5 rounded"
                style={{ backgroundColor: `${color}30` }}
              >
                <Icon className="size-4" style={{ color }} />
              </div>
              <span className="text-white text-sm font-medium">
                {source.name}
              </span>
              {isSelected && (
                <div
                  className="ml-auto w-2 h-2 rounded-full"
                  style={{ backgroundColor: color }}
                />
              )}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
