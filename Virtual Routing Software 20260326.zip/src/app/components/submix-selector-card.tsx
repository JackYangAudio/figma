import { useState, useRef, useEffect } from "react";
import { X, Edit2, Check } from "lucide-react";

interface SubmixSelectorCardProps {
  output: {
    id: string;
    name: string;
    nickname?: string;
    color: string;
  };
  isSelected: boolean;
  canDelete: boolean;
  onSelect: (id: string) => void;
  onNicknameChange: (id: string, nickname: string) => void;
  onDelete: (id: string) => void;
}

export function SubmixSelectorCard({
  output,
  isSelected,
  canDelete,
  onSelect,
  onNicknameChange,
  onDelete,
}: SubmixSelectorCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [nicknameValue, setNicknameValue] = useState(output.nickname || "");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    onNicknameChange(output.id, nicknameValue);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setNicknameValue(output.nickname || "");
    setIsEditing(false);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(output.id);
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditing(true);
  };

  return (
    <div
      className={`relative p-4 rounded-lg border-2 transition-all group ${
        isSelected
          ? "bg-zinc-800 scale-105"
          : "bg-zinc-900 hover:bg-zinc-800"
      }`}
      style={{
        borderColor: isSelected ? output.color : "#3f3f46",
      }}
    >
      {/* Delete Button - Only show for deletable submixes */}
      {canDelete && (
        <button
          onClick={handleDelete}
          className="absolute -top-2 -right-2 p-1.5 rounded-full bg-red-500/90 border border-red-600 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600 z-10"
          title="Delete submix"
        >
          <X className="size-3 text-white" />
        </button>
      )}

      {/* Edit Button - Always available */}
      {!isEditing && (
        <button
          onClick={handleEdit}
          className="absolute -top-2 -left-2 p-1.5 rounded-full bg-blue-500/90 border border-blue-600 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-blue-600 z-10"
          title="Edit nickname"
        >
          <Edit2 className="size-3 text-white" />
        </button>
      )}

      {/* Main Content */}
      <div onClick={() => !isEditing && onSelect(output.id)} className="cursor-pointer">
        {isEditing ? (
          <div className="flex flex-col gap-2" onClick={(e) => e.stopPropagation()}>
            <input
              ref={inputRef}
              type="text"
              value={nicknameValue}
              onChange={(e) => setNicknameValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSave();
                if (e.key === "Escape") handleCancel();
              }}
              className="w-full px-2 py-1 text-sm font-semibold text-white bg-zinc-950 border border-zinc-600 rounded focus:outline-none focus:border-blue-500"
              style={{ color: output.color }}
              maxLength={20}
              placeholder={output.name}
            />
            <div className="flex gap-2 justify-center">
              <button
                onClick={handleSave}
                className="p-1.5 rounded bg-green-500/20 border border-green-500/50 hover:bg-green-500/40"
              >
                <Check className="size-4 text-green-400" />
              </button>
              <button
                onClick={handleCancel}
                className="p-1.5 rounded bg-red-500/20 border border-red-500/50 hover:bg-red-500/40"
              >
                <X className="size-4 text-red-400" />
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="text-lg font-bold" style={{ color: output.color }}>
              {output.nickname || output.name}
            </div>
            {output.nickname && (
              <div className="text-xs text-zinc-500">({output.name})</div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
