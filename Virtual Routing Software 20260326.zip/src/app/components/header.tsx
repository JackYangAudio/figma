import { Settings, Plus, Save, Download, Maximize2 } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Slider } from "./ui/slider";
import { useState, useRef, useEffect } from "react";

interface HeaderProps {
  connectedCount: number;
  zoomLevel: number;
  onAddSource: () => void;
  onSavePreset: () => void;
  onExport: () => void;
  onFitToScreen: () => void;
  onZoomChange: (zoom: number) => void;
}

export function Header({ connectedCount, zoomLevel, onAddSource, onSavePreset, onExport, onFitToScreen, onZoomChange }: HeaderProps) {
  const [isEditingZoom, setIsEditingZoom] = useState(false);
  const [zoomInput, setZoomInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditingZoom && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditingZoom]);

  const handleZoomClick = () => {
    setZoomInput(Math.round(zoomLevel * 100).toString());
    setIsEditingZoom(true);
  };

  const handleZoomInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, "");
    setZoomInput(value);
  };

  const handleZoomInputSubmit = () => {
    const numValue = parseInt(zoomInput, 10);
    if (!isNaN(numValue) && numValue >= 25 && numValue <= 100) {
      onZoomChange(numValue / 100);
    }
    setIsEditingZoom(false);
  };

  const handleZoomInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleZoomInputSubmit();
    } else if (e.key === "Escape") {
      setIsEditingZoom(false);
    }
  };

  return (
    <div className="bg-zinc-900 border-b border-zinc-800 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Settings className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Virtual Router</h1>
              <p className="text-sm text-zinc-400">Audio & Video Routing Software</p>
            </div>
          </div>
          <Badge variant="outline" className="gap-2 border-emerald-500/50 text-emerald-400">
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
            {connectedCount} Active Routes
          </Badge>
        </div>

        <div className="flex items-center gap-4">
          {/* Zoom Controls */}
          <div className="flex items-center gap-3 bg-zinc-800 px-4 py-2 rounded-lg border border-zinc-700">
            {isEditingZoom ? (
              <input
                ref={inputRef}
                type="text"
                value={zoomInput}
                onChange={handleZoomInputChange}
                onBlur={handleZoomInputSubmit}
                onKeyDown={handleZoomInputKeyDown}
                className="w-[45px] bg-zinc-700 text-white text-sm text-center px-1 py-0.5 rounded border border-zinc-600 focus:outline-none focus:border-blue-500"
              />
            ) : (
              <button
                onClick={handleZoomClick}
                className="text-sm text-zinc-400 min-w-[45px] hover:text-white hover:bg-zinc-700 rounded px-1 py-0.5 transition-colors cursor-pointer"
              >
                {Math.round(zoomLevel * 100)}%
              </button>
            )}
            <Slider
              value={[zoomLevel * 100]}
              onValueChange={(value) => onZoomChange(value[0] / 100)}
              min={25}
              max={100}
              step={5}
              className="w-[120px]"
            />
            <Button variant="ghost" size="sm" onClick={onFitToScreen} className="h-8 px-2">
              <Maximize2 className="size-4" />
            </Button>
          </div>

          <Button variant="outline" size="sm" onClick={onAddSource}>
            <Plus className="size-4 mr-2" />
            Add Source
          </Button>
          <Button variant="outline" size="sm" onClick={onSavePreset}>
            <Save className="size-4 mr-2" />
            Save Preset
          </Button>
          <Button variant="outline" size="sm" onClick={onExport}>
            <Download className="size-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
    </div>
  );
}