import { useState } from "react";
import { RotaryKnob } from "./rotary-knob";

interface EQBand {
  frequency: number; // Hz
  gain: number; // -12 to +12 dB
  q: number; // 0.1 to 10
}

interface EQSettings {
  lowShelf: EQBand;
  midPeak: EQBand;
  highShelf: EQBand;
}

interface VSTEQProps {
  settings: EQSettings;
  onSettingsChange: (settings: EQSettings) => void;
}

export function VSTEQ({ settings, onSettingsChange }: VSTEQProps) {
  const [activeBand, setActiveBand] = useState<"lowShelf" | "midPeak" | "highShelf">("midPeak");

  const updateBand = <K extends keyof EQSettings>(
    band: K,
    key: keyof EQBand,
    value: number
  ) => {
    onSettingsChange({
      ...settings,
      [band]: { ...settings[band], [key]: value },
    });
  };

  const eqCurve = generateEQCurve(settings);

  return (
    <div className="p-6 bg-gradient-to-br from-zinc-900 to-zinc-950 rounded-lg">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">3-Band EQ</h3>
        <div className="px-3 py-1 bg-purple-500/20 border border-purple-500/30 rounded text-purple-400 text-xs font-semibold">
          VST3
        </div>
      </div>

      {/* EQ Visualization */}
      <div className="bg-zinc-800/50 rounded-lg p-4 mb-6 h-40 relative overflow-hidden">
        <svg className="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
          {/* Grid */}
          <line x1="0" y1="50" x2="400" y2="50" stroke="#3f3f46" strokeWidth="1" />
          <line x1="100" y1="0" x2="100" y2="100" stroke="#3f3f46" strokeWidth="0.5" />
          <line x1="200" y1="0" x2="200" y2="100" stroke="#3f3f46" strokeWidth="0.5" />
          <line x1="300" y1="0" x2="300" y2="100" stroke="#3f3f46" strokeWidth="0.5" />
          
          {/* EQ Curve */}
          <polyline
            points={eqCurve}
            fill="none"
            stroke="#8b5cf6"
            strokeWidth="2"
            className="drop-shadow-lg"
          />
          <polyline
            points={eqCurve}
            fill="url(#gradient)"
            opacity="0.3"
          />
          
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>

        {/* Frequency Labels */}
        <div className="absolute bottom-2 left-4 right-4 flex justify-between text-[10px] text-zinc-500">
          <span>20Hz</span>
          <span>200Hz</span>
          <span>2kHz</span>
          <span>20kHz</span>
        </div>
      </div>

      {/* Band Selector */}
      <div className="flex gap-2 mb-6">
        {[
          { key: "lowShelf", label: "Low", color: "#ef4444" },
          { key: "midPeak", label: "Mid", color: "#8b5cf6" },
          { key: "highShelf", label: "High", color: "#3b82f6" },
        ].map((band) => (
          <button
            key={band.key}
            onClick={() => setActiveBand(band.key as any)}
            className="flex-1 py-2 px-4 rounded-lg font-semibold text-sm transition-all"
            style={{
              backgroundColor: activeBand === band.key ? `${band.color}30` : "#18181b",
              borderColor: band.color,
              borderWidth: "2px",
              color: activeBand === band.key ? band.color : "#71717a",
            }}
          >
            {band.label}
          </button>
        ))}
      </div>

      {/* Controls for Active Band */}
      <div className="grid grid-cols-3 gap-6">
        {/* Frequency */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={getFrequencyPercent(settings[activeBand].frequency)}
            onChange={(val) => {
              const freq = getFrequencyFromPercent(val);
              updateBand(activeBand, "frequency", freq);
            }}
            color="#8b5cf6"
            size={70}
          />
          <div className="text-center">
            <div className="text-white font-semibold">
              {formatFrequency(settings[activeBand].frequency)}
            </div>
            <div className="text-zinc-500 text-xs">Frequency</div>
          </div>
        </div>

        {/* Gain */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={(settings[activeBand].gain + 12) / 24 * 100}
            onChange={(val) => {
              const gain = (val / 100) * 24 - 12;
              updateBand(activeBand, "gain", gain);
            }}
            color={settings[activeBand].gain >= 0 ? "#10b981" : "#ef4444"}
            size={70}
          />
          <div className="text-center">
            <div className="text-white font-semibold">
              {settings[activeBand].gain >= 0 ? "+" : ""}
              {settings[activeBand].gain.toFixed(1)} dB
            </div>
            <div className="text-zinc-500 text-xs">Gain</div>
          </div>
        </div>

        {/* Q (Bandwidth) */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={(settings[activeBand].q - 0.1) / 9.9 * 100}
            onChange={(val) => {
              const q = (val / 100) * 9.9 + 0.1;
              updateBand(activeBand, "q", q);
            }}
            color="#f59e0b"
            size={70}
          />
          <div className="text-center">
            <div className="text-white font-semibold">
              {settings[activeBand].q.toFixed(2)}
            </div>
            <div className="text-zinc-500 text-xs">Q Factor</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper functions
function getFrequencyPercent(freq: number): number {
  // Logarithmic scale: 20Hz to 20kHz
  const minLog = Math.log(20);
  const maxLog = Math.log(20000);
  const freqLog = Math.log(freq);
  return ((freqLog - minLog) / (maxLog - minLog)) * 100;
}

function getFrequencyFromPercent(percent: number): number {
  const minLog = Math.log(20);
  const maxLog = Math.log(20000);
  const freqLog = minLog + (percent / 100) * (maxLog - minLog);
  return Math.exp(freqLog);
}

function formatFrequency(freq: number): string {
  if (freq >= 1000) {
    return `${(freq / 1000).toFixed(1)}k Hz`;
  }
  return `${Math.round(freq)} Hz`;
}

function generateEQCurve(settings: EQSettings): string {
  const points: string[] = [];
  const width = 400;
  const height = 100;
  const centerY = height / 2;

  for (let x = 0; x <= width; x += 2) {
    const percent = (x / width) * 100;
    const freq = getFrequencyFromPercent(percent);
    
    let totalGain = 0;
    
    // Low shelf
    totalGain += calculateShelfResponse(freq, settings.lowShelf.frequency, settings.lowShelf.gain, "low");
    
    // Mid peak
    totalGain += calculatePeakResponse(freq, settings.midPeak.frequency, settings.midPeak.gain, settings.midPeak.q);
    
    // High shelf
    totalGain += calculateShelfResponse(freq, settings.highShelf.frequency, settings.highShelf.gain, "high");
    
    // Convert gain to Y position (inverted)
    const y = centerY - (totalGain / 12) * (height / 2);
    const clampedY = Math.max(0, Math.min(height, y));
    
    points.push(`${x},${clampedY}`);
  }
  
  // Close the polygon for fill
  points.push(`${width},${height}`);
  points.push(`0,${height}`);
  
  return points.join(" ");
}

function calculatePeakResponse(freq: number, centerFreq: number, gain: number, q: number): number {
  const w = freq / centerFreq;
  const a = Math.pow(10, gain / 40);
  const denominator = 1 + (1 / q) * Math.abs(w - 1 / w);
  return gain / (1 + Math.pow(denominator, 2));
}

function calculateShelfResponse(freq: number, cornerFreq: number, gain: number, type: "low" | "high"): number {
  const ratio = freq / cornerFreq;
  if (type === "low") {
    return gain / (1 + Math.pow(ratio, 2));
  } else {
    return gain / (1 + Math.pow(1 / ratio, 2));
  }
}

export const defaultEQSettings: EQSettings = {
  lowShelf: { frequency: 100, gain: 0, q: 0.7 },
  midPeak: { frequency: 1000, gain: 0, q: 1.0 },
  highShelf: { frequency: 8000, gain: 0, q: 0.7 },
};
