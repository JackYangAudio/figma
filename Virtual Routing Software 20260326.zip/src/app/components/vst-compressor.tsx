import { RotaryKnob } from "./rotary-knob";
import { Slider } from "./ui/slider";

interface CompressorSettings {
  threshold: number; // -60 to 0 dB
  ratio: number; // 1:1 to 20:1
  attack: number; // 0.1 to 100 ms
  release: number; // 10 to 1000 ms
  makeupGain: number; // 0 to 30 dB
}

interface VSTCompressorProps {
  settings: CompressorSettings;
  onSettingsChange: (settings: CompressorSettings) => void;
}

export function VSTCompressor({ settings, onSettingsChange }: VSTCompressorProps) {
  const updateSetting = <K extends keyof CompressorSettings>(
    key: K,
    value: CompressorSettings[K]
  ) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  return (
    <div className="p-6 bg-gradient-to-br from-zinc-900 to-zinc-950 rounded-lg">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Compressor</h3>
        <div className="px-3 py-1 bg-blue-500/20 border border-blue-500/30 rounded text-blue-400 text-xs font-semibold">
          VST3
        </div>
      </div>

      {/* Gain Reduction Meter */}
      <div className="mb-6">
        <div className="text-xs text-zinc-400 mb-2">Gain Reduction</div>
        <div className="h-3 bg-zinc-800 rounded-full overflow-hidden relative">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-red-500 via-yellow-500 to-green-500 opacity-60" />
        </div>
      </div>

      {/* Knobs Row */}
      <div className="grid grid-cols-5 gap-6 mb-6">
        {/* Threshold */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={(settings.threshold + 60) / 60 * 100}
            onChange={(val) => updateSetting("threshold", (val / 100) * 60 - 60)}
            color="#3b82f6"
            size={60}
          />
          <div className="text-center">
            <div className="text-white font-semibold text-sm">
              {settings.threshold.toFixed(1)} dB
            </div>
            <div className="text-zinc-500 text-xs">Threshold</div>
          </div>
        </div>

        {/* Ratio */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={(settings.ratio - 1) / 19 * 100}
            onChange={(val) => updateSetting("ratio", (val / 100) * 19 + 1)}
            color="#3b82f6"
            size={60}
          />
          <div className="text-center">
            <div className="text-white font-semibold text-sm">
              {settings.ratio.toFixed(1)}:1
            </div>
            <div className="text-zinc-500 text-xs">Ratio</div>
          </div>
        </div>

        {/* Attack */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={(settings.attack - 0.1) / 99.9 * 100}
            onChange={(val) => updateSetting("attack", (val / 100) * 99.9 + 0.1)}
            color="#3b82f6"
            size={60}
          />
          <div className="text-center">
            <div className="text-white font-semibold text-sm">
              {settings.attack.toFixed(1)} ms
            </div>
            <div className="text-zinc-500 text-xs">Attack</div>
          </div>
        </div>

        {/* Release */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={(settings.release - 10) / 990 * 100}
            onChange={(val) => updateSetting("release", (val / 100) * 990 + 10)}
            color="#3b82f6"
            size={60}
          />
          <div className="text-center">
            <div className="text-white font-semibold text-sm">
              {settings.release.toFixed(0)} ms
            </div>
            <div className="text-zinc-500 text-xs">Release</div>
          </div>
        </div>

        {/* Makeup Gain */}
        <div className="flex flex-col items-center gap-2">
          <RotaryKnob
            value={settings.makeupGain / 30 * 100}
            onChange={(val) => updateSetting("makeupGain", (val / 100) * 30)}
            color="#10b981"
            size={60}
          />
          <div className="text-center">
            <div className="text-white font-semibold text-sm">
              +{settings.makeupGain.toFixed(1)} dB
            </div>
            <div className="text-zinc-500 text-xs">Makeup</div>
          </div>
        </div>
      </div>

      {/* Visualization */}
      <div className="bg-zinc-800/50 rounded-lg p-4 h-32 flex items-end justify-center gap-1">
        {[...Array(40)].map((_, i) => (
          <div
            key={i}
            className="w-2 bg-blue-500/40 rounded-t"
            style={{
              height: `${Math.random() * 60 + 20}%`,
              transition: "height 0.1s",
            }}
          />
        ))}
      </div>
    </div>
  );
}

export const defaultCompressorSettings: CompressorSettings = {
  threshold: -20,
  ratio: 4,
  attack: 5,
  release: 100,
  makeupGain: 0,
};
