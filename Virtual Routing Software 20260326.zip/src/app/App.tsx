import { useState, useCallback } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { Header } from "./components/header";
import { AudioChannel, AudioChannelData } from "./components/audio-channel";
import { DraggableAudioChannel } from "./components/draggable-audio-channel";
import { SubmixToggle, SubmixToggleData } from "./components/submix-toggle";
import { SubmixSelectorCard } from "./components/submix-selector-card";
import { RoutingMatrixAdvanced } from "./components/routing-matrix-advanced";
import { SimpleRoutingMatrix } from "./components/routing-matrix-simple";
import { VisualRouter } from "./components/visual-router";
import { AudioSource } from "./components/source-selector";
import { VSTInsertData, defaultVSTInsert } from "./components/vst-insert";
import { AudioInterface } from "./components/audio-interface";
import { Card } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { toast } from "sonner";
import { Toaster } from "./components/ui/sonner";
import { Plus, Monitor, Sliders, Grid3x3, GitBranch } from "lucide-react";

const initialInputs: AudioChannelData[] = [
  {
    id: "input-1",
    name: "Microphone",
    type: "input",
    volume: 75,
    muted: false,
    icon: "mic",
    color: "#3b82f6",
    active: true,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-2",
    name: "System Audio",
    type: "input",
    volume: 60,
    muted: false,
    icon: "monitor",
    color: "#10b981",
    active: true,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-3",
    name: "Game Audio",
    type: "input",
    volume: 80,
    muted: false,
    icon: "music",
    color: "#f59e0b",
    active: true,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-4",
    name: "Music",
    type: "input",
    volume: 45,
    muted: false,
    icon: "music",
    color: "#ec4899",
    active: true,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-5",
    name: "Discord",
    type: "input",
    volume: 65,
    muted: false,
    icon: "headphones",
    color: "#8b5cf6",
    active: true,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-6",
    name: "Browser",
    type: "input",
    volume: 55,
    muted: false,
    icon: "monitor",
    color: "#06b6d4",
    active: true,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-7",
    name: "Media Player",
    type: "input",
    volume: 70,
    muted: false,
    icon: "music",
    color: "#ef4444",
    active: false,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-8",
    name: "SFX",
    type: "input",
    volume: 50,
    muted: false,
    icon: "music",
    color: "#14b8a6",
    active: false,
    vstInsert: { ...defaultVSTInsert },
  },
  {
    id: "input-9",
    name: "Aux Input",
    type: "input",
    volume: 60,
    muted: false,
    icon: "mic",
    color: "#f97316",
    active: false,
    vstInsert: { ...defaultVSTInsert },
  },
];

const initialOutputs: AudioChannelData[] = [
  {
    id: "output-1",
    name: "Submix A",
    type: "output",
    volume: 85,
    muted: false,
    icon: "monitor",
    color: "#8b5cf6",
    active: true,
    sendToPC2: false,
  },
  {
    id: "output-2",
    name: "Submix B",
    type: "output",
    volume: 80,
    muted: false,
    icon: "headphones",
    color: "#06b6d4",
    active: true,
    sendToPC2: false,
  },
  {
    id: "output-3",
    name: "Submix C",
    type: "output",
    volume: 90,
    muted: false,
    icon: "monitor",
    color: "#ef4444",
    active: true,
    sendToPC2: false,
  },
];

const initialConnections = [
  // Submix A (Stream) - Mic, System, Game, Discord with different send levels
  { inputId: "input-1", outputId: "output-1", volume: 85 },
  { inputId: "input-2", outputId: "output-1", volume: 70 },
  { inputId: "input-3", outputId: "output-1", volume: 90 },
  { inputId: "input-5", outputId: "output-1", volume: 65 },
  
  // Submix B (Monitoring) - All active inputs at full level
  { inputId: "input-1", outputId: "output-2", volume: 100 },
  { inputId: "input-2", outputId: "output-2", volume: 80 },
  { inputId: "input-3", outputId: "output-2", volume: 85 },
  { inputId: "input-4", outputId: "output-2", volume: 60 },
  { inputId: "input-5", outputId: "output-2", volume: 75 },
  { inputId: "input-6", outputId: "output-2", volume: 70 },
  
  // Submix C (Recording) - Mic, Game, Music at recording levels
  { inputId: "input-1", outputId: "output-3", volume: 90 },
  { inputId: "input-3", outputId: "output-3", volume: 95 },
  { inputId: "input-4", outputId: "output-3", volume: 50 },
];

export default function App() {
  // Deduplicate inputs and outputs on initialization to prevent key conflicts
  const deduplicateById = <T extends { id: string }>(items: T[]): T[] => {
    const seen = new Set<string>();
    return items.filter((item) => {
      if (seen.has(item.id)) {
        console.warn(`Duplicate ID detected and removed: ${item.id}`);
        return false;
      }
      seen.add(item.id);
      return true;
    });
  };

  const [inputs, setInputs] = useState<AudioChannelData[]>(() => deduplicateById(initialInputs));
  const [outputs, setOutputs] = useState<AudioChannelData[]>(() => deduplicateById(initialOutputs));
  const [connections, setConnections] = useState(initialConnections);
  const [selectedSubmixId, setSelectedSubmixId] = useState<string>("output-1");
  const [zoomLevel, setZoomLevel] = useState(1);
  const [simpleMatrixMode, setSimpleMatrixMode] = useState(false);
  const [activeView, setActiveView] = useState<"interface" | "mixer" | "matrix" | "visual">("interface");

  const handleVolumeChange = (id: string, volume: number) => {
    setInputs((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, volume } : ch))
    );
    setOutputs((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, volume } : ch))
    );
  };

  const handleMuteToggle = (id: string) => {
    setInputs((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, muted: !ch.muted } : ch))
    );
    setOutputs((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, muted: !ch.muted } : ch))
    );
    toast.success("Channel mute toggled");
  };

  const handleActiveToggle = (id: string) => {
    setInputs((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, active: !ch.active } : ch))
    );
    setOutputs((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, active: !ch.active } : ch))
    );
    toast.success("Channel enabled/disabled");
  };

  const handleConnectionToggle = (inputId: string, outputId: string) => {
    setConnections((prev) => {
      const exists = prev.some(
        (c) => c.inputId === inputId && c.outputId === outputId
      );
      if (exists) {
        toast.info("Route disconnected");
        return prev.filter(
          (c) => !(c.inputId === inputId && c.outputId === outputId)
        );
      } else {
        toast.success("Route connected at 75% send level");
        return [...prev, { inputId, outputId, volume: 75 }];
      }
    });
  };

  const handleRouteVolumeChange = (
    inputId: string,
    outputId: string,
    volume: number
  ) => {
    setConnections((prev) =>
      prev.map((c) =>
        c.inputId === inputId && c.outputId === outputId
          ? { ...c, volume }
          : c
      )
    );
  };

  const handleAddSource = useCallback(() => {
    toast.info("Add source dialog would open here");
  }, []);

  const handleSavePreset = () => {
    toast.success("Preset saved successfully!");
  };

  const handleExport = () => {
    toast.success("Configuration exported!");
  };

  const handleFitToScreen = () => {
    // Get the content container
    const contentContainer = document.querySelector('.content-wrapper');
    if (!contentContainer) {
      toast.error("Unable to measure content");
      return;
    }
    
    // Get viewport dimensions (minus header)
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight - 80; // Subtract header height
    
    // Get content dimensions
    const contentWidth = contentContainer.scrollWidth;
    const contentHeight = contentContainer.scrollHeight;
    
    // Calculate zoom to fit both width and height
    const zoomWidth = viewportWidth / contentWidth;
    const zoomHeight = viewportHeight / contentHeight;
    
    // Use the smaller zoom to ensure everything fits
    const optimalZoom = Math.min(zoomWidth, zoomHeight, 1); // Max 100%
    
    setZoomLevel(optimalZoom);
    toast.success(`View scaled to ${Math.round(optimalZoom * 100)}%`);
  };

  const handlePC2Toggle = (id: string) => {
    setOutputs((prev) =>
      prev.map((ch) =>
        ch.id === id ? { ...ch, sendToPC2: !ch.sendToPC2 } : ch
      )
    );
    const output = outputs.find((o) => o.id === id);
    toast.success(
      output?.sendToPC2
        ? `${output.name} disconnected from PC-2`
        : `${output.name} routed to PC-2`
    );
  };

  const moveChannel = useCallback((dragIndex: number, hoverIndex: number) => {
    setInputs((prevInputs) => {
      const newInputs = [...prevInputs];
      const [draggedItem] = newInputs.splice(dragIndex, 1);
      newInputs.splice(hoverIndex, 0, draggedItem);
      return newInputs;
    });
  }, []);

  const handleSourceChange = (channelId: string, source: AudioSource) => {
    setInputs((prev) =>
      prev.map((ch) => (ch.id === channelId ? { ...ch, source } : ch))
    );
    toast.success(`${source.name} assigned to channel`);
  };

  const handleVSTChange = (channelId: string, vstData: VSTInsertData) => {
    setInputs((prev) =>
      prev.map((ch) => (ch.id === channelId ? { ...ch, vstInsert: vstData } : ch))
    );
  };

  const handleNicknameChange = (submixId: string, nickname: string) => {
    setOutputs((prev) =>
      prev.map((ch) => (ch.id === submixId ? { ...ch, nickname } : ch))
    );
    toast.success("Submix nickname updated");
  };

  const handleAddSubmix = () => {
    const newId = `output-${outputs.length + 1}`;
    const letters = ["D", "E", "F", "G", "H", "I", "J"];
    const colors = ["#f59e0b", "#10b981", "#ec4899", "#06b6d4", "#8b5cf6", "#ef4444", "#14b8a6"];
    const icons: Array<"monitor" | "headphones"> = ["monitor", "headphones"];
    
    const newIndex = outputs.length - 3; // Index relative to the first 3 (A, B, C)
    const letter = letters[newIndex] || `${newIndex + 4}`;
    const color = colors[newIndex % colors.length];
    const icon = icons[newIndex % icons.length];
    
    const newSubmix: AudioChannelData = {
      id: newId,
      name: `Submix ${letter}`,
      type: "output",
      volume: 80,
      muted: false,
      icon,
      color,
      active: true,
      sendToPC2: false,
    };
    
    setOutputs((prev) => [...prev, newSubmix]);
    toast.success(`${newSubmix.name} added`);
  };

  const handleDeleteSubmix = (submixId: string) => {
    // Prevent deleting the last submix
    if (outputs.length === 1) {
      toast.error("Cannot delete the last submix");
      return;
    }
    
    // Remove the submix
    const deletedIndex = outputs.findIndex((o) => o.id === submixId);
    const newOutputs = outputs.filter((ch) => ch.id !== submixId);
    
    // Relabel remaining submixes to maintain A, B, C, D order
    const letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"];
    const relabeledOutputs = newOutputs.map((output, index) => {
      const newId = `output-${index + 1}`;
      const oldId = output.id;
      
      // Update connections to use new IDs
      setConnections((prev) =>
        prev.map((c) => (c.outputId === oldId ? { ...c, outputId: newId } : c))
      );
      
      return {
        ...output,
        id: newId,
        name: `Submix ${letters[index]}`,
      };
    });
    
    setOutputs(relabeledOutputs);
    
    // Remove all connections to the deleted submix
    setConnections((prev) => prev.filter((c) => c.outputId !== submixId));
    
    // If the deleted submix was selected, select the first one
    if (selectedSubmixId === submixId) {
      setSelectedSubmixId("output-1");
    } else {
      // Update selected ID if it changed due to relabeling
      const selectedIndex = outputs.findIndex((o) => o.id === selectedSubmixId);
      if (selectedIndex > deletedIndex) {
        setSelectedSubmixId(`output-${selectedIndex}`);
      }
    }
    
    toast.success("Submix deleted and order maintained");
  };

  const handleAddInput = () => {
    // Find the highest input number to avoid duplicates
    const maxInputNum = inputs.reduce((max, input) => {
      const match = input.id.match(/^input-(\d+)$/);
      if (match) {
        const num = parseInt(match[1]);
        return Math.max(max, num);
      }
      return max;
    }, 0);
    
    const newId = `input-${maxInputNum + 1}`;
    
    // Double-check that this ID doesn't already exist (defensive programming)
    if (inputs.some(input => input.id === newId)) {
      toast.error("Error: Duplicate input ID detected. Please try again.");
      console.error("Attempted to create duplicate input ID:", newId);
      return;
    }
    
    const icons: Array<"mic" | "monitor" | "headphones" | "music"> = ["mic", "monitor", "music", "headphones"];
    const colors = ["#3b82f6", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6", "#06b6d4", "#ef4444", "#14b8a6"];
    
    const newIndex = inputs.length;
    const icon = icons[newIndex % icons.length];
    const color = colors[newIndex % colors.length];
    
    const newInput: AudioChannelData = {
      id: newId,
      name: `Input ${maxInputNum + 1}`,
      type: "input",
      volume: 75,
      muted: false,
      icon,
      color,
      active: true,
      vstInsert: { ...defaultVSTInsert },
    };
    
    setInputs((prev) => [...prev, newInput]);
    toast.success(`${newInput.name} added`);
  };

  const handleDeleteInput = (inputId: string) => {
    // Prevent deleting the last input
    if (inputs.length === 1) {
      toast.error("Cannot delete the last input");
      return;
    }
    
    // Remove the input
    const deletedInput = inputs.find((i) => i.id === inputId);
    setInputs((prev) => prev.filter((ch) => ch.id !== inputId));
    
    // Remove all connections to the deleted input
    setConnections((prev) => prev.filter((c) => c.inputId !== inputId));
    
    toast.success(`${deletedInput?.name || "Input"} deleted`);
  };

  const handleInputNameChange = (inputId: string, name: string) => {
    setInputs((prev) =>
      prev.map((ch) => (ch.id === inputId ? { ...ch, name } : ch))
    );
    toast.success("Input name updated");
  };

  const handleOutputNameChange = (outputId: string, name: string) => {
    setOutputs((prev) =>
      prev.map((ch) => (ch.id === outputId ? { ...ch, name } : ch))
    );
    toast.success("Output name updated");
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="min-h-screen bg-black text-white flex">
        <Toaster />
        
        {/* Left Sidebar Navigation */}
        <div className="w-20 bg-zinc-900 border-r border-zinc-800 flex flex-col items-center py-6 gap-4">
          <button
            onClick={() => setActiveView("interface")}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-lg transition-all ${
              activeView === "interface"
                ? "bg-blue-500/20 text-blue-400 border border-blue-500/50"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <Monitor className="size-6" />
            <span className="text-[10px] font-medium">Interface</span>
          </button>

          <button
            onClick={() => setActiveView("mixer")}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-lg transition-all ${
              activeView === "mixer"
                ? "bg-blue-500/20 text-blue-400 border border-blue-500/50"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <Sliders className="size-6" />
            <span className="text-[10px] font-medium">Mixer</span>
          </button>

          <button
            onClick={() => setActiveView("matrix")}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-lg transition-all ${
              activeView === "matrix"
                ? "bg-blue-500/20 text-blue-400 border border-blue-500/50"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <Grid3x3 className="size-6" />
            <span className="text-[10px] font-medium">Matrix</span>
          </button>

          <button
            onClick={() => setActiveView("visual")}
            className={`flex flex-col items-center gap-2 px-4 py-3 rounded-lg transition-all ${
              activeView === "visual"
                ? "bg-blue-500/20 text-blue-400 border border-blue-500/50"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <GitBranch className="size-6" />
            <span className="text-[10px] font-medium">Visual</span>
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          <Header
            connectedCount={connections.length}
            zoomLevel={zoomLevel}
            onAddSource={handleAddSource}
            onSavePreset={handleSavePreset}
            onExport={handleExport}
            onFitToScreen={handleFitToScreen}
            onZoomChange={setZoomLevel}
          />

          <div className="p-6 space-y-6 content-wrapper flex-1 overflow-auto" style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top left' }}>
            {/* Interface View */}
            {activeView === "interface" && <AudioInterface />}

            {/* Mixer View */}
            {activeView === "mixer" && (
              <div className="space-y-6">
                {/* Submix Selector */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-white">
                      Select Submix
                    </h2>
                    <Button
                      onClick={handleAddSubmix}
                      className="bg-green-500/20 hover:bg-green-500/30 border-green-500/50 border text-green-400 hover:text-green-300"
                    >
                      <Plus className="size-4 mr-2" />
                      Add Submix
                    </Button>
                  </div>
                  <div className="flex gap-4 flex-wrap">
                    {outputs.map((output) => (
                      <SubmixSelectorCard
                        key={output.id}
                        output={{
                          id: output.id,
                          name: output.name,
                          nickname: output.nickname,
                          color: output.color,
                        }}
                        isSelected={selectedSubmixId === output.id}
                        canDelete={true}
                        onSelect={setSelectedSubmixId}
                        onNicknameChange={handleNicknameChange}
                        onDelete={handleDeleteSubmix}
                      />
                    ))}
                  </div>
                </div>

                {/* Selected Submix Details */}
                {outputs
                  .filter((output) => output.id === selectedSubmixId)
                  .map((output) => (
                    <div key={output.id}>
                      <h2 className="text-xl font-semibold text-white mb-4">
                        {output.nickname || output.name} Controls
                      </h2>
                      <div className="mb-6">
                        <SubmixToggle
                          submix={{
                            id: output.id,
                            name: output.name,
                            nickname: output.nickname,
                            icon: output.icon as "monitor" | "headphones",
                            color: output.color,
                            active: output.active,
                            volume: output.volume,
                            sendToPC2: output.sendToPC2,
                          }}
                          onToggle={handleActiveToggle}
                          onVolumeChange={handleVolumeChange}
                          onPC2Toggle={handlePC2Toggle}
                          onNicknameChange={handleNicknameChange}
                          onNameChange={handleOutputNameChange}
                          onDelete={handleDeleteSubmix}
                        />
                      </div>

                      {/* Input Channels for Selected Submix */}
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">
                          Input Sends to {output.name}
                        </h3>
                        <Button
                          onClick={handleAddInput}
                          className="bg-blue-500/20 hover:bg-blue-500/30 border-blue-500/50 border text-blue-400 hover:text-blue-300"
                        >
                          <Plus className="size-4 mr-2" />
                          Add Input
                        </Button>
                      </div>
                      <div className="flex gap-3 overflow-x-auto pb-4 mixer-container">
                        {inputs.map((channel, index) => {
                          const connection = connections.find(
                            (c) => c.inputId === channel.id && c.outputId === output.id
                          );
                          const sendVolume = connection?.volume ?? 0;
                          const isConnected = !!connection;

                          return (
                            <DraggableAudioChannel
                              key={`mixer-${output.id}-${channel.id}-${index}`}
                              channel={{
                                ...channel,
                                volume: sendVolume,
                                muted: !isConnected,
                              }}
                              index={index}
                              onVolumeChange={(id, volume) => {
                                if (isConnected) {
                                  handleRouteVolumeChange(id, output.id, volume);
                                } else {
                                  // Auto-connect when adjusting volume
                                  setConnections((prev) => [
                                    ...prev,
                                    { inputId: id, outputId: output.id, volume },
                                  ]);
                                  toast.success(`${channel.name} connected to ${output.name}`);
                                }
                              }}
                              onMuteToggle={(id) => {
                                // Mute toggles connection on/off
                                handleConnectionToggle(id, output.id);
                              }}
                              onActiveToggle={handleActiveToggle}
                              onReorder={moveChannel}
                              onSourceChange={handleSourceChange}
                              onVSTChange={handleVSTChange}
                              onDelete={handleDeleteInput}
                              showDelete={true}
                              onNameChange={handleInputNameChange}
                              channelNumber={index + 1}
                            />
                          );
                        })}
                      </div>
                    </div>
                  ))}
              </div>
            )}

            {/* Matrix View */}
            {activeView === "matrix" && (
              <div>
                <div className="flex justify-end mb-4">
                  <Button
                    variant={simpleMatrixMode ? "default" : "outline"}
                    onClick={() => setSimpleMatrixMode(!simpleMatrixMode)}
                    className="bg-zinc-800 hover:bg-zinc-700 border-zinc-600"
                  >
                    {simpleMatrixMode ? "Advanced Mode" : "Simple Mode"}
                  </Button>
                </div>
                
                {simpleMatrixMode ? (
                  <SimpleRoutingMatrix
                    inputs={inputs.map((i) => ({
                      id: i.id,
                      name: i.name,
                      color: i.color,
                    }))}
                    outputs={outputs.map((o) => ({
                      id: o.id,
                      name: o.name,
                      color: o.color,
                    }))}
                    connections={connections}
                    onConnectionToggle={handleConnectionToggle}
                    onInputNameChange={handleInputNameChange}
                    onOutputNameChange={handleOutputNameChange}
                  />
                ) : (
                  <RoutingMatrixAdvanced
                    inputs={inputs.map((i) => ({
                      id: i.id,
                      name: i.name,
                      color: i.color,
                    }))}
                    outputs={outputs.map((o) => ({
                      id: o.id,
                      name: o.name,
                      color: o.color,
                    }))}
                    connections={connections}
                    onConnectionToggle={handleConnectionToggle}
                    onVolumeChange={handleRouteVolumeChange}
                    onInputNameChange={handleInputNameChange}
                    onOutputNameChange={handleOutputNameChange}
                  />
                )}
              </div>
            )}

            {/* Visual Flow View */}
            {activeView === "visual" && (
              <Card className="p-6 bg-zinc-900 border-zinc-800">
                <VisualRouter
                  inputs={inputs}
                  outputs={outputs}
                  connections={connections}
                  onInputNameChange={handleInputNameChange}
                  onOutputNameChange={handleOutputNameChange}
                />
              </Card>
            )}
          </div>
        </div>
      </div>
    </DndProvider>
  );
}