import { useState } from "react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { GitBranch, Zap } from "lucide-react";

interface RoutingConnection {
  inputId: string;
  outputId: string;
}

interface RoutingMatrixProps {
  inputs: Array<{ id: string; name: string; color: string }>;
  outputs: Array<{ id: string; name: string; color: string }>;
  connections: RoutingConnection[];
  onConnectionToggle: (inputId: string, outputId: string) => void;
}

export function RoutingMatrix({
  inputs,
  outputs,
  connections,
  onConnectionToggle,
}: RoutingMatrixProps) {
  const [hoveredCell, setHoveredCell] = useState<string | null>(null);
  const [hoveredInput, setHoveredInput] = useState<string | null>(null);
  const [hoveredOutput, setHoveredOutput] = useState<string | null>(null);

  const isConnected = (inputId: string, outputId: string) => {
    return connections.some(
      (c) => c.inputId === inputId && c.outputId === outputId
    );
  };

  return (
    <Card className="p-6 bg-zinc-900 border-zinc-800">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GitBranch className="size-5 text-blue-400" />
            <h2 className="text-xl font-semibold text-white">Routing Matrix</h2>
          </div>
          <Badge variant="secondary" className="gap-1">
            <Zap className="size-3" />
            {connections.length} Active Routes
          </Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="p-2 text-left"></th>
                {outputs.map((output) => {
                  const isOutputHovered = hoveredOutput === output.id;
                  const isOutputDimmed =
                    hoveredInput !== null ||
                    (hoveredOutput !== null && hoveredOutput !== output.id);

                  return (
                    <th
                      key={output.id}
                      className="p-2 text-center cursor-pointer transition-opacity"
                      style={{ opacity: isOutputDimmed ? 0.3 : 1 }}
                      onMouseEnter={() => setHoveredOutput(output.id)}
                      onMouseLeave={() => setHoveredOutput(null)}
                    >
                      <div
                        className={`flex flex-col items-center gap-1 transition-transform ${
                          isOutputHovered ? "scale-110" : ""
                        }`}
                      >
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: output.color }}
                        />
                        <span className="text-xs text-zinc-400 font-normal whitespace-nowrap">
                          {output.name}
                        </span>
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {inputs.map((input) => {
                const isInputHovered = hoveredInput === input.id;
                const isInputDimmed =
                  hoveredOutput !== null ||
                  (hoveredInput !== null && hoveredInput !== input.id);

                return (
                  <tr key={input.id} className="border-t border-zinc-800">
                    <td
                      className="p-2 cursor-pointer transition-opacity"
                      style={{ opacity: isInputDimmed ? 0.3 : 1 }}
                      onMouseEnter={() => setHoveredInput(input.id)}
                      onMouseLeave={() => setHoveredInput(null)}
                    >
                      <div
                        className={`flex items-center gap-2 transition-transform ${
                          isInputHovered ? "scale-105" : ""
                        }`}
                      >
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: input.color }}
                        />
                        <span className="text-sm text-white whitespace-nowrap">
                          {input.name}
                        </span>
                      </div>
                    </td>
                    {outputs.map((output) => {
                      const cellKey = `${input.id}-${output.id}`;
                      const connected = isConnected(input.id, output.id);
                      const isHovered = hoveredCell === cellKey;

                      // Determine if this cell should be highlighted or dimmed
                      const isHighlighted =
                        hoveredInput === input.id || hoveredOutput === output.id;
                      const isCellDimmed =
                        (hoveredInput !== null && hoveredInput !== input.id) ||
                        (hoveredOutput !== null && hoveredOutput !== output.id);

                      return (
                        <td key={output.id} className="p-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`w-12 h-12 rounded-lg transition-all ${
                              connected
                                ? "bg-gradient-to-br"
                                : "bg-zinc-800 hover:bg-zinc-700"
                            } ${isHovered || isHighlighted ? "scale-110" : ""}`}
                            style={{
                              ...(connected
                                ? {
                                    backgroundImage: `linear-gradient(135deg, ${input.color}, ${output.color})`,
                                  }
                                : undefined),
                              opacity: isCellDimmed ? 0.2 : 1,
                            }}
                            onClick={() => onConnectionToggle(input.id, output.id)}
                            onMouseEnter={() => setHoveredCell(cellKey)}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {connected && (
                              <div className="w-2 h-2 bg-white rounded-full" />
                            )}
                          </Button>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <p className="text-xs text-zinc-500 text-center">
          Hover over inputs/outputs to highlight routes • Click to toggle connections
        </p>
      </div>
    </Card>
  );
}