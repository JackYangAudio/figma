import { useRef } from "react";
import { useDrag, useDrop } from "react-dnd";
import { AudioChannel, AudioChannelData } from "./audio-channel";
import { AudioSource } from "./source-selector";
import { VSTInsertData } from "./vst-insert";

interface DraggableAudioChannelProps {
  channel: AudioChannelData;
  index: number;
  onVolumeChange: (id: string, volume: number) => void;
  onMuteToggle: (id: string) => void;
  onActiveToggle: (id: string) => void;
  onReorder: (dragIndex: number, hoverIndex: number) => void;
  onSourceChange?: (id: string, source: AudioSource) => void;
  onVSTChange?: (id: string, vstData: VSTInsertData) => void;
  onDelete?: (id: string) => void;
  showDelete?: boolean;
  onNameChange?: (id: string, name: string) => void;
  channelNumber?: number;
}

const ITEM_TYPE = "AUDIO_CHANNEL";

export function DraggableAudioChannel({
  channel,
  index,
  onVolumeChange,
  onMuteToggle,
  onActiveToggle,
  onReorder,
  onSourceChange,
  onVSTChange,
  onDelete,
  showDelete,
  onNameChange,
  channelNumber,
}: DraggableAudioChannelProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag] = useDrag({
    type: ITEM_TYPE,
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ITEM_TYPE,
    hover: (item: { index: number }) => {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) {
        return;
      }

      onReorder(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
  });

  drag(drop(ref));

  return (
    <div
      ref={ref}
      style={{
        opacity: isDragging ? 0.5 : 1,
        cursor: "move",
      }}
    >
      <AudioChannel
        channel={channel}
        onVolumeChange={onVolumeChange}
        onMuteToggle={onMuteToggle}
        onActiveToggle={onActiveToggle}
        onSourceChange={onSourceChange}
        onVSTChange={onVSTChange}
        onDelete={onDelete}
        showDelete={showDelete}
        onNameChange={onNameChange}
        channelNumber={channelNumber}
      />
    </div>
  );
}