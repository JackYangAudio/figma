import { Volume2, VolumeX, Mic, Monitor, Headphones, Music, X } from "lucide-react";
import { Slider } from "./ui/slider";
import { Button } from "./ui/button";
import { Switch } from "./ui/switch";
import { Card } from "./ui/card";
import { SourceSelector, AudioSource } from "./source-selector";
import { VSTInsert, VSTInsertData } from "./vst-insert";
import { useState } from "react";

export interface AudioChannelData {
  id: string;
  name: string;
  type: "input" | "output";
  volume: number;
  muted: boolean;
  icon: "mic" | "monitor" | "headphones" | "music";
  color: string;
  active: boolean;
  sendToPC2?: boolean;
  source?: AudioSource;
  vstInsert?: VSTInsertData;
  nickname?: string;
}

interface AudioChannelProps {
  channel: AudioChannelData;
  onVolumeChange: (id: string, volume: number) => void;
  onMuteToggle: (id: string) => void;
  onActiveToggle: (id: string) => void;
  onSourceChange?: (id: string, source: AudioSource) => void;
  onVSTChange?: (id: string, vstData: VSTInsertData) => void;
  onDelete?: (id: string) => void;
  showDelete?: boolean;
  onNameChange?: (id: string, name: string) => void;
  channelNumber?: number;
}

const iconMap = {
  mic: Mic,
  monitor: Monitor,
  headphones: Headphones,
  music: Music,
};

export function AudioChannel({
  channel,
  onVolumeChange,
  onMuteToggle,
  onActiveToggle,
  onSourceChange,
  onVSTChange,
  onDelete,
  showDelete,
  onNameChange,
  channelNumber,
}: AudioChannelProps) {
  const Icon = iconMap[channel.icon];
  // Display volume directly (no inversion needed)
  const volumePercent = Math.round(channel.volume);
  
  const [isEditingVolume, setIsEditingVolume] = useState(false);
  const [tempVolumeValue, setTempVolumeValue] = useState("");
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempNameValue, setTempNameValue] = useState("");

  const handleVolumeClick = () => {
    if (!channel.active) return;
    setIsEditingVolume(true);
    setTempVolumeValue(volumePercent.toString());
  };

  const handleVolumeSubmit = () => {
    const newVolume = parseInt(tempVolumeValue);
    if (!isNaN(newVolume) && newVolume >= 0 && newVolume <= 100) {
      // Set volume directly
      onVolumeChange(channel.id, newVolume);
    }
    setIsEditingVolume(false);
  };

  const handleVolumeKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleVolumeSubmit();
    } else if (e.key === "Escape") {
      setIsEditingVolume(false);
    }
  };

  const handleNameClick = () => {
    if (!onNameChange) return;
    setIsEditingName(true);
    setTempNameValue(channel.name);
  };

  const handleNameSubmit = () => {
    if (onNameChange && tempNameValue.trim()) {
      onNameChange(channel.id, tempNameValue.trim());
    }
    setIsEditingName(false);
  };

  const handleNameKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleNameSubmit();
    } else if (e.key === "Escape") {
      setIsEditingName(false);
    }
  };

  return (
    <Card className="p-4 bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-colors min-w-[140px]">
      <div className="flex flex-col items-center gap-4 h-full">
        {/* Header */}
        <div className="w-full flex flex-col items-center gap-2">
          {/* Source Selector with Icon */}
          {channel.type === "input" && onSourceChange ? (
            <SourceSelector
              currentSource={channel.source}
              onSourceChange={(source) => onSourceChange(channel.id, source)}
              color={channel.color}
            />
          ) : (
            <div
              className="p-3 rounded-lg"
              style={{ backgroundColor: `${channel.color}20` }}
            >
              <Icon
                className="size-6"
                style={{ color: channel.color }}
              />
            </div>
          )}
          <div className="text-center">
            {isEditingName ? (
              <input
                type="text"
                value={tempNameValue}
                onChange={(e) => setTempNameValue(e.target.value)}
                onBlur={handleNameSubmit}
                onKeyDown={handleNameKeyDown}
                autoFocus
                className="w-full px-2 py-1 text-center text-white font-semibold text-sm bg-zinc-800 border border-zinc-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            ) : (
              <h3
                className={`font-semibold text-white text-sm ${
                  onNameChange ? "cursor-pointer hover:text-blue-400" : ""
                } transition-colors`}
                onClick={handleNameClick}
                title={onNameChange ? "Click to edit name" : ""}
              >
                {channelNumber !== undefined ? `${channelNumber}. ` : ""}{channel.name}
              </h3>
            )}
            <p className="text-xs text-zinc-500 uppercase mt-1">
              {channel.type}
            </p>
          </div>
          <Switch
            checked={channel.active}
            onCheckedChange={() => onActiveToggle(channel.id)}
          />
        </div>

        {/* Volume Meter Visualization - Horizontal */}
        <div className="w-full h-8 bg-zinc-800 rounded-full overflow-hidden relative">
          <div
            className="absolute left-0 top-0 bottom-0 transition-all duration-150 rounded-full"
            style={{
              width: `${channel.muted ? 0 : volumePercent}%`,
              backgroundColor: channel.color,
            }}
          />
        </div>

        {/* Vertical Slider */}
        <div className="flex flex-col items-center gap-2 w-full">
          {isEditingVolume ? (
            <div className="flex items-center gap-1">
              <input
                type="number"
                value={tempVolumeValue}
                onChange={(e) => setTempVolumeValue(e.target.value)}
                onBlur={handleVolumeSubmit}
                onKeyDown={handleVolumeKeyDown}
                min="0"
                max="100"
                autoFocus
                className="w-16 px-2 py-1 text-center text-white font-bold text-lg bg-zinc-800 border border-zinc-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <span className="text-white font-bold text-lg">%</span>
            </div>
          ) : (
            <span
              className={`text-white font-bold text-lg ${
                channel.active ? "cursor-pointer hover:text-blue-400" : "cursor-not-allowed"
              } transition-colors`}
              onClick={handleVolumeClick}
              title={channel.active ? "Click to edit volume" : "Enable channel to edit"}
            >
              {volumePercent}%
            </span>
          )}
          <div className="h-[280px] flex items-center justify-center">
            <Slider
              value={[channel.volume]}
              onValueChange={(value) => onVolumeChange(channel.id, value[0])}
              max={100}
              step={1}
              disabled={!channel.active}
              orientation="vertical"
              className="h-full"
            />
          </div>
          <span className="text-zinc-400 text-xs">Volume</span>
        </div>

        {/* VST Insert */}
        {onVSTChange && (
          <VSTInsert
            vstData={channel.vstInsert || { pluginType: "none", bypassed: false }}
            onPluginChange={(pluginType) => {
              const newVSTData = {
                ...channel.vstInsert,
                pluginType,
                bypassed: false,
              };
              onVSTChange(channel.id, newVSTData);
            }}
            onSettingsChange={(settings) => {
              const newVSTData = {
                ...channel.vstInsert!,
                [`${channel.vstInsert!.pluginType}Settings`]: settings,
              };
              onVSTChange(channel.id, newVSTData);
            }}
            onBypassToggle={() => {
              const newVSTData = {
                ...channel.vstInsert!,
                bypassed: !channel.vstInsert!.bypassed,
              };
              onVSTChange(channel.id, newVSTData);
            }}
            color={channel.color}
            disabled={!channel.active}
          />
        )}

        {/* Mute Button */}
        <Button
          variant={channel.muted ? "default" : "outline"}
          size="sm"
          onClick={() => onMuteToggle(channel.id)}
          disabled={!channel.active}
          className="w-full"
        >
          {channel.muted ? (
            <VolumeX className="size-4 mr-2" />
          ) : (
            <Volume2 className="size-4 mr-2" />
          )}
          {channel.muted ? "Unmute" : "Mute"}
        </Button>

        {/* Delete Button */}
        {showDelete && onDelete && (
          <Button
            variant="destructive"
            size="sm"
            onClick={() => onDelete(channel.id)}
            className="w-full mt-2"
          >
            <X className="size-4 mr-2" />
            Delete
          </Button>
        )}
      </div>
    </Card>
  );
}