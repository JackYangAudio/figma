import { useState } from "react";
import { Card } from "./ui/card";

interface ChannelStripProps {
  name: string;
  onUpdate: (data: ChannelData) => void;
}

interface ChannelData {
  gain: number;
  mon: boolean;
  phantom48V: boolean;
  inst: boolean;
  solo: boolean;
  mute: boolean;
  phase: boolean;
}

function ChannelStrip({ name, onUpdate }: ChannelStripProps) {
  const [gain, setGain] = useState(0);
  const [mon, setMon] = useState(false);
  const [phantom48V, setPhantom48V] = useState(false);
  const [inst, setInst] = useState(false);
  const [solo, setSolo] = useState(false);
  const [mute, setMute] = useState(false);
  const [phase, setPhase] = useState(false);

  const renderButton = (
    label: string,
    active: boolean,
    onClick: () => void,
    disabled: boolean = false
  ) => {
    return (
      <button
        onClick={onClick}
        disabled={disabled}
        className={`px-3 py-1.5 rounded text-xs font-bold transition-all ${
          disabled
            ? "bg-zinc-800 text-zinc-600 cursor-not-allowed"
            : active
            ? "bg-zinc-400 text-zinc-900 shadow-lg"
            : "bg-zinc-700 text-zinc-400 hover:bg-zinc-600"
        }`}
      >
        {label}
      </button>
    );
  };

  const renderKnob = () => {
    const rotation = (gain / 12) * 270 - 135; // -135° to +135° for -12 to +12 range

    return (
      <div className="relative">
        <div
          className="w-20 h-20 rounded-full bg-zinc-700 border-4 border-zinc-600 flex items-center justify-center transition-transform hover:scale-105 cursor-pointer"
          onMouseDown={(e) => {
            const startY = e.clientY;
            const startValue = gain;

            const handleMouseMove = (e: MouseEvent) => {
              const deltaY = startY - e.clientY;
              const newValue = Math.max(-12, Math.min(12, startValue + deltaY / 10));
              setGain(newValue);
              onUpdate({ gain: newValue, mon, phantom48V, inst, solo, mute, phase });
            };

            const handleMouseUp = () => {
              document.removeEventListener("mousemove", handleMouseMove);
              document.removeEventListener("mouseup", handleMouseUp);
            };

            document.addEventListener("mousemove", handleMouseMove);
            document.addEventListener("mouseup", handleMouseUp);
          }}
        >
          <div
            className="w-16 h-16 rounded-full bg-gradient-to-br from-zinc-500 to-zinc-700 relative"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            <div className="absolute top-1 left-1/2 -translate-x-1/2">
              <svg width="8" height="12" viewBox="0 0 8 12">
                <polygon points="4,0 8,12 0,12" fill="white" />
              </svg>
            </div>
          </div>
        </div>
        <div className="text-center mt-2 text-sm font-bold text-zinc-300">
          {gain > 0 ? "+" : ""}
          {gain.toFixed(0)}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-zinc-800 rounded-lg p-4 border border-zinc-700 flex flex-col items-center gap-3 min-w-[140px]">
      {/* Channel Name */}
      <div className="text-sm font-bold text-zinc-300">
        {name}
      </div>

      {/* dB Scale */}
      <div className="flex gap-1 items-center">
        <div className="flex flex-col text-[10px] text-zinc-500 font-mono leading-tight text-right">
          <div>-60</div>
          <div className="mt-1">— 0</div>
          <div>— -6</div>
          <div>— -12</div>
          <div className="mt-1">— -24</div>
          <div className="mt-2">— -36</div>
          <div className="mt-4">— -60</div>
        </div>

        {/* Buttons Column */}
        <div className="flex flex-col gap-1.5">
          {renderButton("MON", mon, () => {
            setMon(!mon);
            onUpdate({ gain, mon: !mon, phantom48V, inst, solo, mute, phase });
          })}
          {renderButton("48V", phantom48V, () => {
            setPhantom48V(!phantom48V);
            onUpdate({ gain, mon, phantom48V: !phantom48V, inst, solo, mute, phase });
          })}
          {renderButton("INST", inst, () => {
            setInst(!inst);
            onUpdate({ gain, mon, phantom48V, inst: !inst, solo, mute, phase });
          })}
          {renderButton("SOLO", solo, () => {
            setSolo(!solo);
            onUpdate({ gain, mon, phantom48V, inst, solo: !solo, mute, phase });
          })}
          {renderButton("MUTE", mute, () => {
            setMute(!mute);
            onUpdate({ gain, mon, phantom48V, inst, solo, mute: !mute, phase });
          })}
          {renderButton("Ø", phase, () => {
            setPhase(!phase);
            onUpdate({ gain, mon, phantom48V, inst, solo, mute, phase: !phase });
          })}
        </div>
      </div>

      {/* Gain Knob */}
      {renderKnob()}
    </div>
  );
}

export function ConsoleInterface() {
  const [channels, setChannels] = useState<ChannelData[]>([
    { gain: 0, mon: false, phantom48V: false, inst: false, solo: false, mute: false, phase: false },
    { gain: 0, mon: false, phantom48V: false, inst: false, solo: false, mute: false, phase: false },
    { gain: 0, mon: false, phantom48V: false, inst: false, solo: false, mute: false, phase: false },
    { gain: 0, mon: false, phantom48V: false, inst: false, solo: false, mute: false, phase: false },
  ]);

  const handleChannelUpdate = (index: number, data: ChannelData) => {
    const newChannels = [...channels];
    newChannels[index] = data;
    setChannels(newChannels);
  };

  return (
    <Card className="bg-zinc-900 p-6 border-2 border-zinc-800 shadow-2xl max-w-5xl mx-auto">
      <div className="mb-4">
        <h2 className="text-lg font-bold text-zinc-400">Input</h2>
      </div>
      <div className="flex gap-4 justify-center flex-wrap">
        <ChannelStrip
          name="XLR 1"
          onUpdate={(data) => handleChannelUpdate(0, data)}
        />
        <ChannelStrip
          name="XLR 2"
          onUpdate={(data) => handleChannelUpdate(1, data)}
        />
        <ChannelStrip
          name="XLR 3"
          onUpdate={(data) => handleChannelUpdate(2, data)}
        />
        <ChannelStrip
          name="XLR 4"
          onUpdate={(data) => handleChannelUpdate(3, data)}
        />
      </div>
    </Card>
  );
}