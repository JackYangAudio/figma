import { useState } from "react";
import { Card } from "./ui/card";
import { Power } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ConsoleInterface } from "./console-interface";

export function AudioInterface() {
  const [interfaceType, setInterfaceType] = useState<"hardware" | "console">("hardware");
  const [inputGain1, setInputGain1] = useState(50);
  const [inputGain2, setInputGain2] = useState(50);
  const [monitorLevel, setMonitorLevel] = useState(65);
  const [phantom1, setPhantom1] = useState(false);
  const [phantom2, setPhantom2] = useState(false);
  const [air1, setAir1] = useState(false);
  const [air2, setAir2] = useState(false);
  const [inst1, setInst1] = useState(false);
  const [inst2, setInst2] = useState(false);
  const [pad1, setPad1] = useState(false);
  const [pad2, setPad2] = useState(false);

  // If console view is selected, render that instead
  if (interfaceType === "console") {
    return (
      <div className="space-y-4">
        <div className="flex justify-center">
          <Select value={interfaceType} onValueChange={(value) => setInterfaceType(value as "hardware" | "console")}>
            <SelectTrigger className="w-[280px] bg-zinc-800 border-zinc-700">
              <SelectValue placeholder="Select Interface Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hardware">Hardware Interface (Scarlett 4i4)</SelectItem>
              <SelectItem value="console">Console Mixer</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <ConsoleInterface />
      </div>
    );
  }

  const renderKnob = (
    value: number,
    onChange: (value: number) => void,
    color: string = "#ef4444",
    size: "large" | "small" = "large"
  ) => {
    const rotation = (value / 100) * 270 - 135; // -135° to +135°
    const knobSize = size === "large" ? "w-20 h-20" : "w-16 h-16";
    const innerSize = size === "large" ? "w-16 h-16" : "w-12 h-12";

    return (
      <div className="relative">
        <div
          className={`${knobSize} rounded-full bg-zinc-800 border-4 border-zinc-700 flex items-center justify-center cursor-pointer transition-transform hover:scale-105`}
          onMouseDown={(e) => {
            const startY = e.clientY;
            const startValue = value;

            const handleMouseMove = (e: MouseEvent) => {
              const deltaY = startY - e.clientY;
              const newValue = Math.max(0, Math.min(100, startValue + deltaY));
              onChange(newValue);
            };

            const handleMouseUp = () => {
              document.removeEventListener("mousemove", handleMouseMove);
              document.removeEventListener("mouseup", handleMouseUp);
            };

            document.addEventListener("mousemove", handleMouseMove);
            document.addEventListener("mouseup", handleMouseUp);
          }}
        >
          <div
            className={`${innerSize} rounded-full bg-gradient-to-br from-zinc-600 to-zinc-800 relative`}
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            <div
              className="absolute top-1 left-1/2 -translate-x-1/2 w-1 h-3 rounded-full"
              style={{ backgroundColor: color }}
            />
          </div>
        </div>
        {/* Value arc */}
        <svg
          className="absolute inset-0 pointer-events-none"
          viewBox="0 0 100 100"
        >
          <circle
            cx="50"
            cy="50"
            r="42"
            fill="none"
            stroke="#27272a"
            strokeWidth="6"
            strokeDasharray="212"
            strokeDashoffset="0"
            transform="rotate(-135 50 50)"
          />
          <circle
            cx="50"
            cy="50"
            r="42"
            fill="none"
            stroke={color}
            strokeWidth="6"
            strokeDasharray="212"
            strokeDashoffset={212 - (value / 100) * 212}
            transform="rotate(-135 50 50)"
            strokeLinecap="round"
          />
        </svg>
      </div>
    );
  };

  const renderButton = (
    label: string,
    active: boolean,
    onClick: () => void,
    color: string = "#10b981"
  ) => {
    return (
      <button
        onClick={onClick}
        className={`px-3 py-1.5 rounded text-xs font-medium transition-all ${
          active
            ? "bg-opacity-100 text-white shadow-lg"
            : "bg-zinc-700 text-zinc-400 hover:text-zinc-200"
        }`}
        style={{
          backgroundColor: active ? color : undefined,
          boxShadow: active ? `0 0 12px ${color}80` : undefined,
        }}
      >
        {label}
      </button>
    );
  };

  const renderIndicator = (active: boolean, color: string = "#10b981") => {
    return (
      <div
        className={`w-3 h-3 rounded-full border-2 transition-all ${
          active ? "border-transparent" : "border-zinc-600 bg-zinc-800"
        }`}
        style={{
          backgroundColor: active ? color : undefined,
          boxShadow: active ? `0 0 8px ${color}` : undefined,
        }}
      />
    );
  };

  return (
    <Card className="bg-gradient-to-br from-red-600 to-red-700 p-6 border-4 border-red-800 shadow-2xl max-w-4xl mx-auto">
      {/* Interface Type Selector */}
      <div className="flex justify-center mb-4">
        <Select value={interfaceType} onValueChange={(value) => setInterfaceType(value as "hardware" | "console")}>
          <SelectTrigger className="w-[280px] bg-zinc-900 border-zinc-700 text-white">
            <SelectValue placeholder="Select Interface Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hardware">Hardware Interface (Scarlett 4i4)</SelectItem>
            <SelectItem value="console">Console Mixer</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-zinc-900 rounded-lg p-6 border-2 border-zinc-800">
        <div className="grid grid-cols-[auto_1fr_auto] gap-8 items-center">
          {/* Left Section - Input Channels */}
          <div className="flex gap-6">
            {/* Input 1 */}
            <div className="flex flex-col items-center gap-3">
              <div className="flex gap-2">
                {renderIndicator(phantom1, "#ef4444")}
                {renderIndicator(inst1, "#10b981")}
              </div>
              {renderKnob(inputGain1, setInputGain1, "#10b981")}
              <div className="flex flex-col gap-1">
                <button
                  onClick={() => setInst1(!inst1)}
                  className="w-12 h-12 rounded-full bg-zinc-800 border-2 border-zinc-700 flex items-center justify-center hover:border-zinc-600 transition-colors"
                >
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <circle
                      cx="12"
                      cy="12"
                      r="8"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-zinc-500"
                    />
                    <circle
                      cx="12"
                      cy="12"
                      r="4"
                      fill="currentColor"
                      className="text-zinc-600"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Input 2 */}
            <div className="flex flex-col items-center gap-3">
              <div className="flex gap-2">
                {renderIndicator(phantom2, "#ef4444")}
                {renderIndicator(inst2, "#10b981")}
              </div>
              {renderKnob(inputGain2, setInputGain2, "#10b981")}
              <div className="flex flex-col gap-1">
                <button
                  onClick={() => setInst2(!inst2)}
                  className="w-12 h-12 rounded-full bg-zinc-800 border-2 border-zinc-700 flex items-center justify-center hover:border-zinc-600 transition-colors"
                >
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <circle
                      cx="12"
                      cy="12"
                      r="8"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-zinc-500"
                    />
                    <circle
                      cx="12"
                      cy="12"
                      r="4"
                      fill="currentColor"
                      className="text-zinc-600"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Middle Section - Controls */}
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-2">
                <span className="text-xs text-zinc-400 font-medium">
                  48V
                </span>
                <div className="flex gap-2">
                  {renderButton("1", phantom1, () => setPhantom1(!phantom1), "#ef4444")}
                  {renderButton("2", phantom2, () => setPhantom2(!phantom2), "#ef4444")}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <span className="text-xs text-zinc-400 font-medium">AIR</span>
                <div className="flex gap-2">
                  {renderButton("1", air1, () => setAir1(!air1), "#3b82f6")}
                  {renderButton("2", air2, () => setAir2(!air2), "#3b82f6")}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-2">
                <span className="text-xs text-zinc-400 font-medium">PAD</span>
                <div className="flex gap-2">
                  {renderButton("1", pad1, () => setPad1(!pad1), "#f59e0b")}
                  {renderButton("2", pad2, () => setPad2(!pad2), "#f59e0b")}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <span className="text-xs text-zinc-400 font-medium">
                  Direct
                </span>
                <button className="px-3 py-1.5 bg-zinc-700 text-zinc-400 rounded text-xs font-medium hover:text-zinc-200 transition-colors">
                  Monitor
                </button>
              </div>
            </div>

            {/* Brand */}
            <div className="text-center mt-2">
              <span className="text-xl font-bold text-zinc-400">Scarlett</span>
              <span className="text-xs text-zinc-500 ml-2">4i4</span>
            </div>
          </div>

          {/* Right Section - Monitor & Power */}
          <div className="flex flex-col items-center gap-4">
            <div className="text-xs text-zinc-400 font-medium">Monitor</div>
            {renderKnob(monitorLevel, setMonitorLevel, "#10b981", "large")}
            <button className="w-10 h-10 rounded-full bg-zinc-800 border-2 border-zinc-700 flex items-center justify-center hover:border-zinc-600 transition-colors mt-4">
              <Power className="w-5 h-5 text-zinc-500" />
            </button>
          </div>
        </div>
      </div>
    </Card>
  );
}