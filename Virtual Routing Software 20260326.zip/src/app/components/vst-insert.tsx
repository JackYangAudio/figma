import { useState } from "react";
import { Sliders, ChevronDown, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { VSTCompressor, defaultCompressorSettings } from "./vst-compressor";
import { VSTEQ, defaultEQSettings } from "./vst-eq";

export type VSTPluginType = "none" | "compressor" | "eq";

export interface VSTInsertData {
  pluginType: VSTPluginType;
  compressorSettings?: any;
  eqSettings?: any;
  bypassed: boolean;
}

interface VSTInsertProps {
  vstData: VSTInsertData;
  onPluginChange: (pluginType: VSTPluginType) => void;
  onSettingsChange: (settings: any) => void;
  onBypassToggle: () => void;
  color: string;
  disabled?: boolean;
}

const pluginOptions = [
  { id: "none", name: "No Plugin", icon: X },
  { id: "compressor", name: "Compressor", icon: Sliders },
  { id: "eq", name: "EQ", icon: Sliders },
];

export function VSTInsert({
  vstData,
  onPluginChange,
  onSettingsChange,
  onBypassToggle,
  color,
  disabled,
}: VSTInsertProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const hasPlugin = vstData.pluginType !== "none";
  const pluginName = pluginOptions.find((p) => p.id === vstData.pluginType)?.name || "No Plugin";

  const handleDoubleClick = () => {
    if (hasPlugin && !disabled) {
      setDialogOpen(true);
    }
  };

  return (
    <>
      {/* VST Insert Slot */}
      <div className="w-full space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-zinc-400 text-xs font-medium">VST Insert</span>
          {hasPlugin && (
            <button
              onClick={onBypassToggle}
              disabled={disabled}
              className="text-[10px] px-2 py-0.5 rounded transition-all font-semibold"
              style={{
                backgroundColor: vstData.bypassed ? "#3f3f46" : `${color}30`,
                color: vstData.bypassed ? "#a1a1aa" : color,
                borderWidth: "1px",
                borderColor: vstData.bypassed ? "#52525b" : color,
              }}
            >
              {vstData.bypassed ? "BYPASSED" : "ACTIVE"}
            </button>
          )}
        </div>

        <div className="relative">
          {/* Plugin Display/Editor */}
          <div
            className="w-full p-3 rounded-lg border-2 transition-all cursor-pointer group"
            style={{
              backgroundColor: hasPlugin && !vstData.bypassed ? `${color}10` : "#18181b",
              borderColor: hasPlugin && !vstData.bypassed ? color : "#3f3f46",
              opacity: disabled ? 0.5 : 1,
            }}
            onDoubleClick={handleDoubleClick}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders
                  className="size-4"
                  style={{
                    color: hasPlugin && !vstData.bypassed ? color : "#71717a",
                  }}
                />
                <span
                  className="text-sm font-semibold"
                  style={{
                    color: hasPlugin && !vstData.bypassed ? color : "#71717a",
                  }}
                >
                  {pluginName}
                </span>
              </div>

              {/* Dropdown Selector */}
              <DropdownMenu open={dropdownOpen} onOpenChange={setDropdownOpen}>
                <DropdownMenuTrigger asChild>
                  <button
                    disabled={disabled}
                    className="p-1 rounded hover:bg-zinc-800 transition-colors"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ChevronDown className="size-4 text-zinc-400" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-48 bg-zinc-900 border-zinc-800">
                  <div className="px-2 py-1.5 text-xs font-semibold text-zinc-400">
                    Select Plugin
                  </div>
                  {pluginOptions.map((plugin) => {
                    const Icon = plugin.icon;
                    const isSelected = vstData.pluginType === plugin.id;
                    return (
                      <DropdownMenuItem
                        key={plugin.id}
                        onClick={() => {
                          onPluginChange(plugin.id as VSTPluginType);
                          setDropdownOpen(false);
                        }}
                        className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-zinc-800"
                        style={{
                          backgroundColor: isSelected ? `${color}20` : undefined,
                        }}
                      >
                        <Icon className="size-4" style={{ color }} />
                        <span className="text-white text-sm">{plugin.name}</span>
                        {isSelected && (
                          <div
                            className="ml-auto w-2 h-2 rounded-full"
                            style={{ backgroundColor: color }}
                          />
                        )}
                      </DropdownMenuItem>
                    );
                  })}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {hasPlugin && (
              <div className="mt-2 text-[10px] text-zinc-500 group-hover:text-zinc-400 transition-colors">
                Double-click to edit
              </div>
            )}
          </div>
        </div>
      </div>

      {/* VST Editor Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl bg-zinc-950 border-zinc-800">
          <DialogHeader>
            <DialogTitle className="text-white">VST Plugin Editor</DialogTitle>
            <DialogDescription className="text-sm text-zinc-500">
              Adjust the settings of your VST plugin.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            {vstData.pluginType === "compressor" && (
              <VSTCompressor
                settings={vstData.compressorSettings || defaultCompressorSettings}
                onSettingsChange={onSettingsChange}
              />
            )}
            {vstData.pluginType === "eq" && (
              <VSTEQ
                settings={vstData.eqSettings || defaultEQSettings}
                onSettingsChange={onSettingsChange}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export const defaultVSTInsert: VSTInsertData = {
  pluginType: "none",
  bypassed: false,
};