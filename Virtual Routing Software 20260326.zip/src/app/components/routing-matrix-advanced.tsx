import { useState } from "react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { GitBranch, Zap } from "lucide-react";
import { Slider } from "./ui/slider";
import { Button } from "./ui/button";

interface RoutingConnection {
  inputId: string;
  outputId: string;
  volume: number;
}

interface RoutingMatrixAdvancedProps {
  inputs: Array<{ id: string; name: string; color: string }>;
  outputs: Array<{ id: string; name: string; color: string }>;
  connections: RoutingConnection[];
  onConnectionToggle: (inputId: string, outputId: string) => void;
  onVolumeChange: (inputId: string, outputId: string, volume: number) => void;
  onInputNameChange?: (inputId: string, name: string) => void;
  onOutputNameChange?: (outputId: string, name: string) => void;
}

export function RoutingMatrixAdvanced({
  inputs,
  outputs,
  connections,
  onConnectionToggle,
  onVolumeChange,
  onInputNameChange,
  onOutputNameChange,
}: RoutingMatrixAdvancedProps) {
  const [hoveredCell, setHoveredCell] = useState<string | null>(null);
  const [hoveredInput, setHoveredInput] = useState<string | null>(null);
  const [hoveredOutput, setHoveredOutput] = useState<string | null>(null);
  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [tempVolumeValue, setTempVolumeValue] = useState("");
  const [editingInputName, setEditingInputName] = useState<string | null>(null);
  const [tempInputName, setTempInputName] = useState("");
  const [editingOutputName, setEditingOutputName] = useState<string | null>(null);
  const [tempOutputName, setTempOutputName] = useState("");

  const getConnection = (inputId: string, outputId: string) => {
    return connections.find(
      (c) => c.inputId === inputId && c.outputId === outputId
    );
  };

  const handleVolumeClick = (inputId: string, outputId: string, currentVolume: number) => {
    const cellKey = `${inputId}-${outputId}`;
    setEditingCell(cellKey);
    setTempVolumeValue(Math.round(currentVolume).toString());
  };

  const handleVolumeSubmit = (inputId: string, outputId: string) => {
    const newVolume = parseInt(tempVolumeValue);
    if (!isNaN(newVolume) && newVolume >= 0 && newVolume <= 100) {
      onVolumeChange(inputId, outputId, newVolume);
    }
    setEditingCell(null);
  };

  const handleVolumeKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, inputId: string, outputId: string) => {
    if (e.key === "Enter") {
      handleVolumeSubmit(inputId, outputId);
    } else if (e.key === "Escape") {
      setEditingCell(null);
    }
  };

  const handleInputNameClick = (inputId: string, currentName: string) => {
    setEditingInputName(inputId);
    setTempInputName(currentName);
  };

  const handleInputNameSubmit = (inputId: string) => {
    if (onInputNameChange) {
      onInputNameChange(inputId, tempInputName);
    }
    setEditingInputName(null);
  };

  const handleInputNameKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, inputId: string) => {
    if (e.key === "Enter") {
      handleInputNameSubmit(inputId);
    } else if (e.key === "Escape") {
      setEditingInputName(null);
    }
  };

  const handleOutputNameClick = (outputId: string, currentName: string) => {
    setEditingOutputName(outputId);
    setTempOutputName(currentName);
  };

  const handleOutputNameSubmit = (outputId: string) => {
    if (onOutputNameChange) {
      onOutputNameChange(outputId, tempOutputName);
    }
    setEditingOutputName(null);
  };

  const handleOutputNameKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, outputId: string) => {
    if (e.key === "Enter") {
      handleOutputNameSubmit(outputId);
    } else if (e.key === "Escape") {
      setEditingOutputName(null);
    }
  };

  return (
    <Card className="p-6 bg-zinc-900 border-zinc-800">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GitBranch className="size-5 text-blue-400" />
            <h2 className="text-xl font-semibold text-white">Routing Matrix</h2>
          </div>
          <Badge variant="secondary" className="gap-1">
            <Zap className="size-3" />
            {connections.length} Active Routes
          </Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="p-2 text-left sticky left-0 bg-zinc-900 z-10">
                  <span className="text-xs text-zinc-400 uppercase">Input / Output</span>
                </th>
                {outputs.map((output) => {
                  const isOutputHovered = hoveredOutput === output.id;
                  const isOutputDimmed = hoveredInput !== null || (hoveredOutput !== null && hoveredOutput !== output.id);
                  
                  return (
                    <th 
                      key={`header-${output.id}`} 
                      className="p-2 text-center min-w-[140px] cursor-pointer transition-opacity"
                      style={{ opacity: isOutputDimmed ? 0.3 : 1 }}
                      onMouseEnter={() => setHoveredOutput(output.id)}
                      onMouseLeave={() => setHoveredOutput(null)}
                    >
                      <div className={`flex flex-col items-center gap-1 transition-transform ${isOutputHovered ? 'scale-110' : ''}`}>
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: output.color }}
                        />
                        <span className="text-sm text-white font-medium whitespace-nowrap">
                          {editingOutputName === output.id ? (
                            <input
                              type="text"
                              value={tempOutputName}
                              onChange={(e) => setTempOutputName(e.target.value)}
                              onBlur={() => handleOutputNameSubmit(output.id)}
                              onKeyDown={(e) => handleOutputNameKeyDown(e, output.id)}
                              autoFocus
                              className="w-14 px-1 py-0.5 text-center font-medium bg-zinc-700 border border-zinc-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              style={{ color: output.color }}
                              onClick={(e) => e.stopPropagation()}
                            />
                          ) : (
                            <span
                              className="font-medium cursor-pointer hover:text-blue-400 transition-colors"
                              style={{ color: output.color }}
                              onClick={() => handleOutputNameClick(output.id, output.name)}
                              title="Click to edit output name"
                            >
                              {output.name}
                            </span>
                          )}
                        </span>
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {inputs.map((input) => {
                const isInputHovered = hoveredInput === input.id;
                const isInputDimmed = hoveredOutput !== null || (hoveredInput !== null && hoveredInput !== input.id);
                
                return (
                  <tr key={input.id} className="border-t border-zinc-800">
                    <td 
                      className="p-2 sticky left-0 bg-zinc-900 z-10 cursor-pointer transition-opacity"
                      style={{ opacity: isInputDimmed ? 0.3 : 1 }}
                      onMouseEnter={() => setHoveredInput(input.id)}
                      onMouseLeave={() => setHoveredInput(null)}
                    >
                      <div className={`flex items-center gap-2 transition-transform ${isInputHovered ? 'scale-105' : ''}`}>
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: input.color }}
                        />
                        <span className="text-sm text-white whitespace-nowrap">
                          {editingInputName === input.id ? (
                            <input
                              type="text"
                              value={tempInputName}
                              onChange={(e) => setTempInputName(e.target.value)}
                              onBlur={() => handleInputNameSubmit(input.id)}
                              onKeyDown={(e) => handleInputNameKeyDown(e, input.id)}
                              autoFocus
                              className="w-14 px-1 py-0.5 text-center font-medium bg-zinc-700 border border-zinc-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              style={{ color: input.color }}
                              onClick={(e) => e.stopPropagation()}
                            />
                          ) : (
                            <span
                              className="font-medium cursor-pointer hover:text-blue-400 transition-colors"
                              style={{ color: input.color }}
                              onClick={() => handleInputNameClick(input.id, input.name)}
                              title="Click to edit input name"
                            >
                              {input.name}
                            </span>
                          )}
                        </span>
                      </div>
                    </td>
                    {outputs.map((output) => {
                      const cellKey = `${input.id}-${output.id}`;
                      const connection = getConnection(input.id, output.id);
                      const isHovered = hoveredCell === cellKey;
                      
                      // Determine if this cell should be highlighted or dimmed
                      const isHighlighted = (hoveredInput === input.id) || (hoveredOutput === output.id);
                      const isCellDimmed = 
                        (hoveredInput !== null && hoveredInput !== input.id) ||
                        (hoveredOutput !== null && hoveredOutput !== output.id);

                      return (
                        <td key={output.id} className="p-2">
                          <div
                            className={`rounded-lg p-3 transition-all ${
                              connection
                                ? "bg-zinc-800 border border-zinc-700"
                                : "bg-zinc-900 border border-zinc-800"
                            } ${isHovered || isHighlighted ? "scale-105 ring-2 ring-blue-500/50" : ""}`}
                            style={{ opacity: isCellDimmed ? 0.2 : 1 }}
                            onMouseEnter={() => setHoveredCell(cellKey)}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {connection ? (
                              <div className="space-y-2">
                                {/* Volume Level Indicator */}
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-zinc-400">Send</span>
                                  {editingCell === cellKey ? (
                                    <div className="flex items-center gap-1">
                                      <input
                                        type="number"
                                        value={tempVolumeValue}
                                        onChange={(e) => setTempVolumeValue(e.target.value)}
                                        onBlur={() => handleVolumeSubmit(input.id, output.id)}
                                        onKeyDown={(e) => handleVolumeKeyDown(e, input.id, output.id)}
                                        min="0"
                                        max="100"
                                        autoFocus
                                        className="w-14 px-1 py-0.5 text-center font-medium bg-zinc-700 border border-zinc-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        style={{ color: input.color }}
                                        onClick={(e) => e.stopPropagation()}
                                      />
                                      <span className="font-medium" style={{ color: input.color }}>%</span>
                                    </div>
                                  ) : (
                                    <span
                                      className="font-medium cursor-pointer hover:text-blue-400 transition-colors"
                                      style={{ color: input.color }}
                                      onClick={() => handleVolumeClick(input.id, output.id, connection.volume)}
                                      title="Click to edit send level"
                                    >
                                      {Math.round(connection.volume)}%
                                    </span>
                                  )}
                                </div>

                                {/* Volume Slider */}
                                <Slider
                                  value={[connection.volume]}
                                  onValueChange={(value) =>
                                    onVolumeChange(input.id, output.id, value[0])
                                  }
                                  max={100}
                                  step={1}
                                  className="w-full"
                                />

                                {/* Disconnect Button */}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="w-full h-7 text-xs"
                                  onClick={() => onConnectionToggle(input.id, output.id)}
                                >
                                  Disconnect
                                </Button>
                              </div>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full"
                                onClick={() => onConnectionToggle(input.id, output.id)}
                              >
                                Connect
                              </Button>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <p className="text-xs text-zinc-500 text-center">
          Hover over inputs/outputs to highlight routes • Adjust send volume per submix
        </p>
      </div>
    </Card>
  );
}