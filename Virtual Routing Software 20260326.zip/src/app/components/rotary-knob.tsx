import { useRef, useState, useEffect } from "react";

interface RotaryKnobProps {
  value: number; // 0-100
  onChange: (value: number) => void;
  size?: number;
  color: string;
  disabled?: boolean;
}

export function RotaryKnob({
  value,
  onChange,
  size = 80,
  color,
  disabled = false,
}: RotaryKnobProps) {
  const [isDragging, setIsDragging] = useState(false);
  const knobRef = useRef<HTMLDivElement>(null);
  const startY = useRef(0);
  const startValue = useRef(0);

  // Convert value (0-100) to rotation angle (-135 to 135 degrees)
  const valueToAngle = (val: number) => {
    return -135 + (val / 100) * 270;
  };

  const angle = valueToAngle(value);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (disabled) return;
    e.preventDefault();
    setIsDragging(true);
    startY.current = e.clientY;
    startValue.current = value;
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;

      const deltaY = startY.current - e.clientY;
      const sensitivity = 0.5;
      const newValue = Math.max(
        0,
        Math.min(100, startValue.current + deltaY * sensitivity)
      );

      onChange(Math.round(newValue));
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging, onChange]);

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        ref={knobRef}
        className="relative cursor-pointer select-none"
        style={{ width: size, height: size }}
        onMouseDown={handleMouseDown}
      >
        {/* Outer ring */}
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="absolute inset-0"
        >
          {/* Background arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={size / 2 - 4}
            fill="none"
            stroke="#27272a"
            strokeWidth="6"
          />
          {/* Value arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={size / 2 - 4}
            fill="none"
            stroke={color}
            strokeWidth="6"
            strokeDasharray={`${(value / 100) * 270 * 0.55} ${270 * 0.55}`}
            strokeDashoffset={67.5 * 0.55}
            strokeLinecap="round"
            transform={`rotate(-225 ${size / 2} ${size / 2})`}
            style={{
              transition: isDragging ? "none" : "stroke-dasharray 0.1s ease",
            }}
          />
        </svg>

        {/* Knob body */}
        <div
          className="absolute inset-0 rounded-full flex items-center justify-center transition-transform"
          style={{
            background: `linear-gradient(135deg, #3f3f46 0%, #18181b 100%)`,
            margin: "8px",
            boxShadow: isDragging
              ? "inset 0 2px 8px rgba(0,0,0,0.6)"
              : "0 4px 12px rgba(0,0,0,0.5), inset 0 1px 2px rgba(255,255,255,0.1)",
            transform: isDragging ? "scale(0.98)" : "scale(1)",
          }}
        >
          {/* Indicator line */}
          <div
            className="absolute w-1 rounded-full"
            style={{
              height: size * 0.3,
              top: size * 0.15,
              backgroundColor: color,
              boxShadow: `0 0 8px ${color}`,
              transform: `rotate(${angle}deg)`,
              transformOrigin: `center ${size * 0.35}px`,
              transition: isDragging ? "none" : "transform 0.1s ease",
            }}
          />
        </div>

        {/* Center dot */}
        <div
          className="absolute rounded-full"
          style={{
            width: size * 0.15,
            height: size * 0.15,
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            backgroundColor: "#52525b",
          }}
        />
      </div>

      {/* Value display */}
      <div className="text-center">
        <div className="text-[11px] font-bold" style={{ color }}>
          {Math.round(value)}%
        </div>
      </div>
    </div>
  );
}