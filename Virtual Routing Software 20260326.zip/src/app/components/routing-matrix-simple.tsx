import { Card } from "./ui/card";
import { useState } from "react";

interface SimpleRoutingMatrixProps {
  inputs: { id: string; name: string; color: string }[];
  outputs: { id: string; name: string; color: string }[];
  connections: { inputId: string; outputId: string; volume: number }[];
  onConnectionToggle: (inputId: string, outputId: string) => void;
  onInputNameChange?: (inputId: string, name: string) => void;
  onOutputNameChange?: (outputId: string, name: string) => void;
}

export function SimpleRoutingMatrix({
  inputs,
  outputs,
  connections,
  onConnectionToggle,
  onInputNameChange,
  onOutputNameChange,
}: SimpleRoutingMatrixProps) {
  const [hoveredInput, setHoveredInput] = useState<string | null>(null);
  const [hoveredOutput, setHoveredOutput] = useState<string | null>(null);
  
  const isConnected = (inputId: string, outputId: string) => {
    return connections.some(
      (c) => c.inputId === inputId && c.outputId === outputId
    );
  };

  return (
    <Card className="p-6 bg-zinc-900 border-zinc-800 overflow-x-auto">
      <div className="min-w-max">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="p-3 text-left text-zinc-400 text-sm font-semibold">
                Input → Output
              </th>
              {outputs.map((output) => {
                const isOutputHovered = hoveredOutput === output.id;
                const isOutputDimmed = hoveredInput !== null || (hoveredOutput !== null && hoveredOutput !== output.id);
                
                return (
                  <th
                    key={`simple-header-${output.id}`}
                    className="p-3 text-center text-sm font-semibold cursor-pointer transition-all"
                    style={{ 
                      color: output.color,
                      opacity: isOutputDimmed ? 0.3 : 1,
                      transform: isOutputHovered ? 'scale(1.1)' : 'scale(1)',
                    }}
                    onMouseEnter={() => setHoveredOutput(output.id)}
                    onMouseLeave={() => setHoveredOutput(null)}
                  >
                    {output.name}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {inputs.map((input) => {
              const isInputHovered = hoveredInput === input.id;
              const isInputDimmed = hoveredOutput !== null || (hoveredInput !== null && hoveredInput !== input.id);
              
              return (
                <tr
                  key={input.id}
                  className="border-t border-zinc-800 hover:bg-zinc-800/50 transition-colors"
                >
                  <td
                    className="p-3 font-semibold text-sm cursor-pointer transition-all"
                    style={{ 
                      color: input.color,
                      opacity: isInputDimmed ? 0.3 : 1,
                      transform: isInputHovered ? 'scale(1.05)' : 'scale(1)',
                    }}
                    onMouseEnter={() => setHoveredInput(input.id)}
                    onMouseLeave={() => setHoveredInput(null)}
                  >
                    {input.name}
                  </td>
                  {outputs.map((output) => {
                    const connected = isConnected(input.id, output.id);
                    
                    // Determine if this cell should be highlighted or dimmed
                    const isHighlighted = (hoveredInput === input.id) || (hoveredOutput === output.id);
                    const isCellDimmed = 
                      (hoveredInput !== null && hoveredInput !== input.id) ||
                      (hoveredOutput !== null && hoveredOutput !== output.id);
                    
                    return (
                      <td key={output.id} className="p-3 text-center">
                        <button
                          onClick={() => onConnectionToggle(input.id, output.id)}
                          className="w-12 h-12 rounded-lg transition-all transform hover:scale-110 active:scale-95"
                          style={{
                            backgroundColor: connected
                              ? output.color
                              : "transparent",
                            borderWidth: "2px",
                            borderColor: connected ? output.color : "#3f3f46",
                            boxShadow: connected
                              ? `0 0 20px ${output.color}40`
                              : "none",
                            opacity: isCellDimmed ? 0.2 : 1,
                            transform: isHighlighted ? 'scale(1.15)' : undefined,
                          }}
                        >
                          {connected && (
                            <div className="flex items-center justify-center">
                              <div className="w-2 h-2 bg-white rounded-full" />
                            </div>
                          )}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
        
        <p className="text-xs text-zinc-500 text-center mt-4">
          Hover over inputs/outputs to highlight routes • Click to toggle connections
        </p>
      </div>
    </Card>
  );
}