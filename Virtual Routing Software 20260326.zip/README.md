
  # Virtual Routing Software

  This is a code bundle for Virtual Routing Software. The original project is available at https://www.figma.com/design/ClFMqYy74NJnxxSeWQJi2y/Virtual-Routing-Software.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  