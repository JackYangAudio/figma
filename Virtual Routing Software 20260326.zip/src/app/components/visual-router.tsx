import { motion } from "motion/react";
import { useState, useEffect } from "react";

interface VolumeLevel {
  id: string;
  level: number;
}

interface VisualRouterProps {
  inputs: Array<{ id: string; name: string; color: string; active: boolean; volume: number; muted: boolean }>;
  outputs: Array<{ id: string; name: string; color: string; active: boolean; volume: number; muted: boolean }>;
  connections: Array<{ inputId: string; outputId: string; volume: number }>;
  onInputNameChange?: (inputId: string, name: string) => void;
  onOutputNameChange?: (outputId: string, name: string) => void;
}

export function VisualRouter({ inputs, outputs, connections, onInputNameChange, onOutputNameChange }: VisualRouterProps) {
  const [volumeLevels, setVolumeLevels] = useState<VolumeLevel[]>([]);
  const [hoveredInput, setHoveredInput] = useState<string | null>(null);
  const [hoveredOutput, setHoveredOutput] = useState<string | null>(null);

  // Simulate volume levels animation
  useEffect(() => {
    const interval = setInterval(() => {
      const activeInputs = inputs.filter((i) => i.active && !i.muted);
      setVolumeLevels(
        activeInputs.map((input) => ({
          id: input.id,
          level: input.volume * (0.7 + Math.random() * 0.3),
        }))
      );
    }, 150);

    return () => clearInterval(interval);
  }, [inputs]);

  // Show all active inputs instead of limiting to 5
  const displayInputs = inputs.filter((input) => input.active);
  const inputCount = displayInputs.length;
  const outputCount = outputs.length;
  const canvasWidth = 900;
  const canvasHeight = 500;
  const padding = 80;
  const nodeRadius = 24;

  // Calculate positions - vertical layout for inputs and outputs
  const inputSpacing = (canvasHeight - padding * 2) / Math.max(inputCount - 1, 1);
  const outputSpacing = (canvasHeight - padding * 2) / Math.max(outputCount - 1, 1);

  const inputPositions = displayInputs.map((_, i) => ({
    x: padding + 100,
    y: inputCount === 1 ? canvasHeight / 2 : padding + i * inputSpacing,
  }));

  const outputPositions = outputs.map((_, i) => ({
    x: canvasWidth - padding - 100,
    y: outputCount === 1 ? canvasHeight / 2 : padding + i * outputSpacing,
  }));

  return (
    <div className="relative w-full overflow-x-auto">
      <div className="relative" style={{ width: canvasWidth, height: canvasHeight }}>
        <svg className="absolute inset-0 w-full h-full">
          <defs>
            {connections.map((conn, i) => {
              const input = displayInputs.find((inp) => inp.id === conn.inputId);
              const output = outputs.find((out) => out.id === conn.outputId);
              if (!input || !output) return null;

              const gradientId = `gradient-${i}`;
              return (
                <linearGradient key={gradientId} id={gradientId} x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor={input.color} />
                  <stop offset="100%" stopColor={output.color} />
                </linearGradient>
              );
            })}
          </defs>

          {/* Connection Lines with Volume Labels */}
          {connections.map((conn, i) => {
            const inputIdx = displayInputs.findIndex((inp) => inp.id === conn.inputId);
            const outputIdx = outputs.findIndex((out) => out.id === conn.outputId);
            const input = displayInputs[inputIdx];
            const output = outputs[outputIdx];

            if (inputIdx === -1 || outputIdx === -1 || !input || !output) return null;

            const start = inputPositions[inputIdx];
            const end = outputPositions[outputIdx];
            
            const controlX1 = start.x + 150;
            const controlX2 = end.x - 150;

            // Calculate midpoint for volume label
            const midX = (start.x + end.x) / 2;
            const midY = (start.y + end.y) / 2;

            const volumeLevel = volumeLevels.find((v) => v.id === input.id);
            const isActive = input.active && !input.muted && output.active && !output.muted;
            
            // Check if this connection should be highlighted based on hover
            const isHighlighted = 
              (hoveredInput === conn.inputId) || 
              (hoveredOutput === conn.outputId);
            const isDimmed = 
              (hoveredInput !== null && hoveredInput !== conn.inputId) ||
              (hoveredOutput !== null && hoveredOutput !== conn.outputId);
            
            // Calculate line thickness based on send volume
            const sendVolume = (conn.volume ?? 75) / 100;
            const strokeWidth = isActive ? 2 + (sendVolume * 5) : 2;
            const enhancedStrokeWidth = isHighlighted ? strokeWidth * 1.5 : strokeWidth;
            
            const baseOpacity = isActive ? 0.5 + (sendVolume * 0.3) : 0.15;
            const dynamicOpacity = volumeLevel && isActive 
              ? baseOpacity * (0.6 + (volumeLevel.level / 250))
              : baseOpacity;
            
            // Adjust opacity based on hover state
            const finalOpacity = isDimmed ? dynamicOpacity * 0.2 : (isHighlighted ? 1 : dynamicOpacity);

            return (
              <g key={`${conn.inputId}-${conn.outputId}`}>
                <motion.path
                  d={`M ${start.x + nodeRadius} ${start.y} C ${controlX1} ${start.y}, ${controlX2} ${end.y}, ${end.x - nodeRadius} ${end.y}`}
                  stroke={`url(#gradient-${i})`}
                  strokeWidth={enhancedStrokeWidth}
                  fill="none"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: finalOpacity }}
                  transition={{ duration: 0.3 }}
                />
                
                {/* Volume Label on Connection */}
                {isActive && (!isDimmed || isHighlighted) && (
                  <motion.g
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ 
                      opacity: isHighlighted ? 1 : (isDimmed ? 0 : 1),
                      scale: isHighlighted ? 1.2 : 1 
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <circle
                      cx={midX}
                      cy={midY}
                      r="16"
                      fill="#18181b"
                      stroke={input.color}
                      strokeWidth="2"
                    />
                    <text
                      x={midX}
                      y={midY}
                      textAnchor="middle"
                      dominantBaseline="central"
                      className="text-xs font-bold"
                      fill="white"
                    >
                      {Math.round(conn.volume)}
                    </text>
                  </motion.g>
                )}
              </g>
            );
          })}
        </svg>

        {/* Input Nodes */}
        {displayInputs.map((input, i) => {
          const pos = inputPositions[i];
          const volumeLevel = volumeLevels.find((v) => v.id === input.id);
          const pulseScale = volumeLevel && input.active && !input.muted 
            ? 1 + (volumeLevel.level / 300) 
            : 1;

          // Count connections for this input
          const connCount = connections.filter(c => c.inputId === input.id).length;
          
          const isHovered = hoveredInput === input.id;
          const isDimmed = hoveredOutput !== null || (hoveredInput !== null && hoveredInput !== input.id);

          return (
            <motion.div
              key={`input-node-${input.id}`}
              className="absolute flex flex-col items-center cursor-pointer"
              style={{
                left: pos.x,
                top: pos.y,
                transform: `translate(-50%, -50%)`,
              }}
              onMouseEnter={() => setHoveredInput(input.id)}
              onMouseLeave={() => setHoveredInput(null)}
            >
              {/* Node Circle */}
              <motion.div
                className="flex items-center justify-center rounded-full border-4 shadow-xl relative"
                style={{
                  width: nodeRadius * 2,
                  height: nodeRadius * 2,
                  backgroundColor: input.active ? input.color : "#3f3f46",
                  borderColor: input.active ? input.color : "#52525b",
                  boxShadow: input.active ? `0 0 20px ${input.color}50` : "none",
                }}
                animate={{ 
                  scale: isHovered ? pulseScale * 1.2 : pulseScale,
                  opacity: isDimmed ? 0.3 : 1
                }}
                transition={{ duration: 0.15 }}
              >
                <span className="text-xs font-bold text-white">IN</span>
                
                {/* Connection Count Badge */}
                {connCount > 0 && (
                  <div 
                    className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{
                      backgroundColor: input.color,
                      border: "2px solid #18181b",
                    }}
                  >
                    {connCount}
                  </div>
                )}
              </motion.div>
              
              {/* Label */}
              <div 
                className="mt-2 text-xs font-semibold text-white whitespace-nowrap text-center"
                style={{ opacity: isDimmed ? 0.3 : 1 }}
              >
                {input.name}
              </div>
              
              {/* Volume indicator */}
              {input.active && !input.muted && (
                <div 
                  className="mt-1 text-[10px] text-zinc-400"
                  style={{ opacity: isDimmed ? 0.3 : 1 }}
                >
                  {Math.round(input.volume)}%
                </div>
              )}
            </motion.div>
          );
        })}

        {/* Output Nodes */}
        {outputs.map((output, i) => {
          const pos = outputPositions[i];
          
          // Count connections to this output
          const connCount = connections.filter(c => c.outputId === output.id).length;
          
          // Calculate average send volume to this output
          const outputConns = connections.filter(c => c.outputId === output.id);
          const avgVolume = outputConns.length > 0 
            ? outputConns.reduce((sum, c) => sum + (c.volume ?? 0), 0) / outputConns.length
            : 0;

          const isHovered = hoveredOutput === output.id;
          const isDimmed = hoveredInput !== null || (hoveredOutput !== null && hoveredOutput !== output.id);

          return (
            <motion.div
              key={output.id}
              className="absolute flex flex-col items-center cursor-pointer"
              style={{
                left: pos.x,
                top: pos.y,
                transform: `translate(-50%, -50%)`,
              }}
              onMouseEnter={() => setHoveredOutput(output.id)}
              onMouseLeave={() => setHoveredOutput(null)}
            >
              {/* Node Circle */}
              <motion.div
                className="flex items-center justify-center rounded-full border-4 shadow-xl relative"
                style={{
                  width: nodeRadius * 2.2,
                  height: nodeRadius * 2.2,
                  backgroundColor: output.active ? output.color : "#3f3f46",
                  borderColor: output.active ? output.color : "#52525b",
                  boxShadow: output.active ? `0 0 25px ${output.color}60` : "none",
                }}
                animate={{
                  scale: isHovered ? 1.2 : 1,
                  opacity: isDimmed ? 0.3 : 1
                }}
                transition={{ duration: 0.15 }}
              >
                <span className="text-xs font-bold text-white">OUT</span>
                
                {/* Connection Count Badge */}
                {connCount > 0 && (
                  <div 
                    className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{
                      backgroundColor: output.color,
                      border: "2px solid #18181b",
                    }}
                  >
                    {connCount}
                  </div>
                )}
              </motion.div>
              
              {/* Label */}
              <div 
                className="mt-2 text-sm font-bold text-white whitespace-nowrap text-center"
                style={{ opacity: isDimmed ? 0.3 : 1 }}
              >
                {output.name}
              </div>
              
              {/* Average volume indicator */}
              {output.active && connCount > 0 && (
                <div 
                  className="mt-1 text-[10px] text-zinc-400"
                  style={{ opacity: isDimmed ? 0.3 : 1 }}
                >
                  Avg: {Math.round(avgVolume)}%
                </div>
              )}
            </motion.div>
          );
        })}

        {/* Legend */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-zinc-900/90 backdrop-blur-sm px-4 py-2 rounded-lg border border-zinc-700">
          <p className="text-xs text-zinc-300 text-center">
            <span className="font-semibold text-white">Hover</span> over inputs/outputs to highlight routes • 
            <span className="font-semibold text-white"> Numbers</span> show send volume %
          </p>
        </div>
      </div>
    </div>
  );
}