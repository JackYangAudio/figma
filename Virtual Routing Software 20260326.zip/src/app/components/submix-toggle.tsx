import { Monitor, Headphones, Laptop2, Check, X } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { RotaryKnob } from "./rotary-knob";
import { Card } from "./ui/card";

export interface SubmixToggleData {
  id: string;
  name: string;
  nickname?: string;
  icon: "monitor" | "headphones";
  color: string;
  active: boolean;
  volume: number;
  sendToPC2?: boolean;
}

interface SubmixToggleProps {
  submix: SubmixToggleData;
  onToggle: (id: string) => void;
  onVolumeChange: (id: string, volume: number) => void;
  onPC2Toggle?: (id: string) => void;
  onNicknameChange?: (id: string, nickname: string) => void;
  onNameChange?: (id: string, name: string) => void;
  onDelete?: (id: string) => void;
}

const iconMap = {
  monitor: Monitor,
  headphones: Headphones,
};

export function SubmixToggle({ 
  submix, 
  onToggle, 
  onVolumeChange, 
  onPC2Toggle,
  onNicknameChange,
  onNameChange,
  onDelete,
}: SubmixToggleProps) {
  const Icon = iconMap[submix.icon];
  const [isEditingNickname, setIsEditingNickname] = useState(false);
  const [nicknameValue, setNicknameValue] = useState(submix.nickname || "");
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameValue, setNameValue] = useState(submix.name);
  const inputRef = useRef<HTMLInputElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditingNickname && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
    if (isEditingName && nameRef.current) {
      nameRef.current.focus();
      nameRef.current.select();
    }
  }, [isEditingNickname, isEditingName]);

  const handleNicknameSave = () => {
    if (onNicknameChange) {
      onNicknameChange(submix.id, nicknameValue);
    }
    setIsEditingNickname(false);
  };

  const handleNicknameCancel = () => {
    setNicknameValue(submix.nickname || "");
    setIsEditingNickname(false);
  };

  const handleNameSave = () => {
    if (onNameChange) {
      onNameChange(submix.id, nameValue);
    }
    setIsEditingName(false);
  };

  const handleNameCancel = () => {
    setNameValue(submix.name);
    setIsEditingName(false);
  };

  const displayName = submix.nickname || submix.name;

  return (
    <Card
      className="p-3 transition-all relative group"
      style={{
        backgroundColor: submix.active ? `${submix.color}20` : "#18181b",
        borderColor: submix.color,
        borderWidth: "2px",
      }}
    >
      {/* Delete Button - Only show for submixes beyond the first 3 */}
      {onDelete && (
        <button
          onClick={() => onDelete(submix.id)}
          className="absolute top-1 right-1 p-1 rounded bg-red-500/20 border border-red-500/50 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/40"
          title="Delete submix"
        >
          <X className="size-3 text-red-400" />
        </button>
      )}

      <div className="flex items-center gap-4 min-w-[200px]">
        {/* Left: Icon and Name */}
        <div className="flex flex-col items-center gap-1 min-w-[80px]">
          <div
            className="p-1 rounded"
            style={{ backgroundColor: `${submix.color}30` }}
          >
            <Icon
              className="size-3"
              style={{ color: submix.color }}
            />
          </div>
          
          {/* Editable Nickname */}
          {isEditingNickname ? (
            <div className="flex flex-col gap-1 w-full">
              <input
                ref={inputRef}
                type="text"
                value={nicknameValue}
                onChange={(e) => setNicknameValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleNicknameSave();
                  if (e.key === "Escape") handleNicknameCancel();
                }}
                className="w-full px-1 py-0.5 text-[10px] font-semibold text-white bg-zinc-900 border border-zinc-700 rounded text-center"
                maxLength={20}
              />
              <div className="flex gap-1 justify-center">
                <button
                  onClick={handleNicknameSave}
                  className="p-0.5 rounded bg-green-500/20 border border-green-500/50 hover:bg-green-500/40"
                >
                  <Check className="size-3 text-green-400" />
                </button>
                <button
                  onClick={handleNicknameCancel}
                  className="p-0.5 rounded bg-red-500/20 border border-red-500/50 hover:bg-red-500/40"
                >
                  <X className="size-3 text-red-400" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-0.5 w-full">
              <h3 
                className="font-bold text-xs text-white text-center cursor-pointer hover:text-zinc-300 transition-colors"
                onClick={() => onNicknameChange && setIsEditingNickname(true)}
                title="Click to edit nickname"
              >
                {displayName}
              </h3>
              {submix.nickname ? (
                isEditingName ? (
                  <div className="flex items-center gap-1">
                    <input
                      ref={nameRef}
                      type="text"
                      value={nameValue}
                      onChange={(e) => setNameValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleNameSave();
                        if (e.key === "Escape") handleNameCancel();
                      }}
                      className="w-16 px-1 py-0.5 text-[9px] text-white bg-zinc-900 border border-zinc-700 rounded text-center"
                      maxLength={15}
                    />
                    <button
                      onClick={handleNameSave}
                      className="p-0.5 rounded bg-green-500/20 border border-green-500/50 hover:bg-green-500/40"
                    >
                      <Check className="size-2 text-green-400" />
                    </button>
                    <button
                      onClick={handleNameCancel}
                      className="p-0.5 rounded bg-red-500/20 border border-red-500/50 hover:bg-red-500/40"
                    >
                      <X className="size-2 text-red-400" />
                    </button>
                  </div>
                ) : (
                  <span 
                    className="text-[9px] text-zinc-500 cursor-pointer hover:text-zinc-400 transition-colors"
                    onClick={() => onNameChange && setIsEditingName(true)}
                    title="Click to edit main name"
                  >
                    ({submix.name})
                  </span>
                )
              ) : (
                isEditingName ? (
                  <div className="flex items-center gap-1 mt-1">
                    <input
                      ref={nameRef}
                      type="text"
                      value={nameValue}
                      onChange={(e) => setNameValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleNameSave();
                        if (e.key === "Escape") handleNameCancel();
                      }}
                      className="w-20 px-1 py-0.5 text-[9px] text-white bg-zinc-900 border border-zinc-700 rounded text-center"
                      maxLength={15}
                    />
                  </div>
                ) : null
              )}
            </div>
          )}
        </div>

        {/* Center: Rotary Knob */}
        <div className="flex-shrink-0">
          <RotaryKnob
            value={submix.volume}
            onChange={(volume) => onVolumeChange(submix.id, volume)}
            color={submix.color}
            disabled={!submix.active}
            size={50}
          />
        </div>

        {/* Right: Toggle Buttons */}
        <div className="flex flex-col gap-1.5 flex-1">
          {/* Toggle Button */}
          <button
            onClick={() => onToggle(submix.id)}
            className="py-1 px-3 rounded text-[10px] font-semibold transition-all"
            style={{
              backgroundColor: submix.active ? submix.color : "transparent",
              borderColor: submix.color,
              borderWidth: "1px",
              color: submix.active ? "white" : submix.color,
            }}
          >
            {submix.active ? "ON" : "OFF"}
          </button>

          {/* PC-2 Send Button */}
          <button
            onClick={() => onPC2Toggle?.(submix.id)}
            className="py-1 px-3 rounded text-[10px] font-semibold transition-all flex items-center justify-center gap-1"
            style={{
              backgroundColor: submix.sendToPC2 ? "#8b5cf6" : "transparent",
              borderColor: "#8b5cf6",
              borderWidth: "1px",
              color: submix.sendToPC2 ? "white" : "#8b5cf6",
            }}
            disabled={!submix.active}
          >
            <Laptop2 className="size-3" />
            <span>PC-2</span>
          </button>
        </div>
      </div>
    </Card>
  );
}